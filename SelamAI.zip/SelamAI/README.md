# SelamAI (`com.selamai.assistant`)

SelamAI (ሰላም AI) is a native Android personal AI assistant built with Kotlin, Jetpack Compose (Material 3), Clean Architecture (`data` / `domain` / `ui`), MVVM, Hilt, Room, OkHttp SSE streaming, Google Tink encryption, and Coil.

## Key Features

- **Google Gemini API (SSE Streaming)**: Connects to `POST https://generativelanguage.googleapis.com/v1beta/models/{model}:streamGenerateContent?alt=sse` with the API key sent strictly in the `x-goog-api-key` header (never in URLs or logs).
- **Resilient Model Fallback**: Defaults to `gemini-3.5-flash-lite` with an editable fallback chain (`gemini-3.8-flash` -> `gemini-4-hydrogen`), exponential backoff + jitter on HTTP 503, `Retry-After` handling on HTTP 429, immediate fallback on HTTP 404, and direct Settings prompt on HTTP 400/401/403.
- **Google Search Grounding**: Optional per-query live web search (`"tools": [{"google_search": {}}]`) with clickable source chips rendered under each reply.
- **Real-Time Gregorian & Ethiopian Clock**: Injects local `ZonedDateTime` and pre-computed Ethiopian Calendar dates (13 months, leap-year accurate) into `system_instruction` on every request.
- **On-Device Personal Memory**: Categorized Room storage (`Goal`, `Preference`, `Habit`, `General`), `<user_memory>` injection with size-cap warnings, streaming-safe `[[MEMORY:Category|Fact]]` auto-learning parser, deduplication, and Save/Dismiss confirmation.
- **Voice & Localization**: `SpeechRecognizer` (`am-ET` / `en-US` chip), `TextToSpeech` with Ethiopic Unicode detection (`\u1200..\u137F`), bundled **Noto Sans Ethiopic** (Regular + Bold), and in-app Amharic/English switching via `AppCompatDelegate.setApplicationLocales`.
- **Multimodal & Phase 1 Features**: Camera capture (`FileProvider`) and Photo Picker (EXIF-corrected, max 1280px JPEG), PDF attachments (up to 15 MB as `application/pdf` `inline_data`), `ACTION_SEND` share-into support (text & images), per-conversation persona override, optional Biometric app lock, UTF-8 `.txt`/`.md` export, and full JSON backup/restore.
- **Phase 2 Architecture Seams**: Ready-to-implement domain interfaces in `domain/phase2/Phase2Interfaces.kt` for Gemini Live API (`gemini-3.8-live`), Latin-to-Ethiopic transliteration, Ethiopian holidays/reminders, and a home-screen quick-ask widget.

## Getting a Google Gemini API Key

1. Open [Google AI Studio](https://aistudio.google.com/apikey) and sign in with your Google account.
2. Click **Create API key** and copy the generated key.
3. Launch **SelamAI**, open the navigation drawer -> **Settings**, paste your key under **Gemini API**, and tap **Save**.
4. The key is encrypted on-device with AES-256-GCM backed by Android Keystore (Google Tink + Jetpack DataStore).

## Local Setup & Build

### Prerequisites
- Android Studio Ladybug (or newer) with **JDK 17**
- Android SDK 35 (`compileSdk = 35`, `targetSdk = 35`, `minSdk = 26`)

### Generate the Gradle Wrapper JAR (First-Time Local Setup)
Because binary JAR files are not bundled in the offline source archive, generate `gradle/wrapper/gradle-wrapper.jar` once locally before committing to Git:

```bash
gradle wrapper --gradle-version 8.10.2
```

*(Note: `.github/workflows/main.yml` automatically provisions Gradle 8.10.2 via `gradle/actions/setup-gradle@v4`, so GitHub Actions builds immediately even before `gradle-wrapper.jar` is committed.)*

### Build Debug APK

```bash
./gradlew assembleDebug
```

Output APK path:
```text
app/build/outputs/apk/debug/app-debug.apk
```

### Run Unit Tests

```bash
./gradlew testDebugUnitTest
```

Unit tests cover:
- `MarkdownParserTest`
- `StreamingMemoryParserTest`
- `EthiopianCalendarConverterTest`
- `GeminiFallbackExecutorTest`
- `EthiopicLanguageDetectorTest`

## Release Signing (Never Commit Your Keystore)

1. Generate a release keystore using `keytool`:

```bash
keytool -genkeypair -v \
  -keystore selamai-release.jks \
  -alias selamai \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000
```

2. Keep `selamai-release.jks` **outside** your Git repository (`.gitignore` already excludes `*.jks` and `*.keystore`).
3. Supply signing credentials via environment variables (locally or as **GitHub Actions Secrets**):

```bash
export SELAMAI_KEYSTORE_PATH="/absolute/path/to/selamai-release.jks"
export SELAMAI_STORE_PASSWORD="your-store-password"
export SELAMAI_KEY_ALIAS="selamai"
export SELAMAI_KEY_PASSWORD="your-key-password"
```

4. Build a minified, R8-shrunk release APK or App Bundle:

```bash
./gradlew assembleRelease
# or for Google Play:
./gradlew bundleRelease
```

`app/build.gradle.kts` automatically wires `signingConfigs.release` when `SELAMAI_KEYSTORE_PATH` is set.
