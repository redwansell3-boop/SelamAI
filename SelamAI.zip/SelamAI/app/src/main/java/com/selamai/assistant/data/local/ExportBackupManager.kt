package com.selamai.assistant.data.local

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import com.selamai.assistant.domain.model.Conversation
import com.selamai.assistant.domain.model.Message
import com.selamai.assistant.domain.model.MessageRole
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.nio.charset.StandardCharsets
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import javax.inject.Inject
import javax.inject.Singleton

@Serializable
data class FullBackupPayload(
    val version: Int = 1,
    val exportedAt: Long = System.currentTimeMillis(),
    val conversations: List<BackupConversation>,
    val messages: List<BackupMessage>,
    val memories: List<BackupMemory>
)

@Serializable
data class BackupConversation(
    val id: Long,
    val title: String,
    val isPinned: Boolean,
    val customSystemPrompt: String? = null,
    val createdAt: Long,
    val updatedAt: Long
)

@Serializable
data class BackupMessage(
    val conversationId: Long,
    val role: String,
    val content: String,
    val modelUsed: String? = null,
    val groundingSourcesJson: String? = null,
    val createdAt: Long
)

@Serializable
data class BackupMemory(
    val category: String,
    val fact: String,
    val createdAt: Long,
    val updatedAt: Long
)

@Singleton
class ExportBackupManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val conversationDao: ConversationDao,
    private val messageDao: MessageDao,
    private val memoryDao: MemoryDao,
    private val json: Json
) {
    private val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")
        .withZone(ZoneId.systemDefault())

    suspend fun createExportFileUri(
        conversation: Conversation,
        messages: List<Message>,
        asMarkdown: Boolean
    ): Uri = withContext(Dispatchers.IO) {
        val exportsDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val ext = if (asMarkdown) "md" else "txt"
        val safeTitle = conversation.title
            .replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .take(40)
            .ifBlank { "selamai_chat" }
        val outFile = File(exportsDir, "${safeTitle}_${System.currentTimeMillis()}.$ext")

        val content = buildString {
            if (asMarkdown) {
                appendLine("# ${conversation.title}")
                appendLine()
            } else {
                appendLine(conversation.title)
                appendLine("=".repeat(conversation.title.length.coerceAtLeast(10)))
                appendLine()
            }
            for (msg in messages) {
                val time = formatter.format(Instant.ofEpochMilli(msg.createdAt))
                val speaker = if (msg.role == MessageRole.USER) "You" else "SelamAI"
                val modelSuffix = msg.modelUsed?.let { " ($it)" } ?: ""
                if (asMarkdown) {
                    appendLine("### $speaker$modelSuffix · $time")
                    appendLine(msg.content)
                    if (msg.groundingSources.isNotEmpty()) {
                        appendLine()
                        appendLine("Sources:")
                        msg.groundingSources.forEach { src ->
                            appendLine("- [${src.title}](${src.uri})")
                        }
                    }
                    appendLine()
                } else {
                    appendLine("[$time] $speaker$modelSuffix:")
                    appendLine(msg.content)
                    if (msg.groundingSources.isNotEmpty()) {
                        appendLine("Sources: " + msg.groundingSources.joinToString(", ") { "${it.title} (${it.uri})" })
                    }
                    appendLine()
                }
            }
        }
        outFile.writeText(content, StandardCharsets.UTF_8)

        FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            outFile
        )
    }

    suspend fun writeFullBackupToUri(uri: Uri) = withContext(Dispatchers.IO) {
        val payload = FullBackupPayload(
            conversations = conversationDao.getAllOnce().map {
                BackupConversation(
                    id = it.id,
                    title = it.title,
                    isPinned = it.isPinned,
                    customSystemPrompt = it.customSystemPrompt,
                    createdAt = it.createdAt,
                    updatedAt = it.updatedAt
                )
            },
            messages = messageDao.getAllOnce().map {
                BackupMessage(
                    conversationId = it.conversationId,
                    role = it.role,
                    content = it.content,
                    modelUsed = it.modelUsed,
                    groundingSourcesJson = it.groundingSourcesJson,
                    createdAt = it.createdAt
                )
            },
            memories = memoryDao.getAllOnce().map {
                BackupMemory(
                    category = it.category,
                    fact = it.fact,
                    createdAt = it.createdAt,
                    updatedAt = it.updatedAt
                )
            }
        )
        val encoded = json.encodeToString(payload)
        context.contentResolver.openOutputStream(uri)?.use { out ->
            out.write(encoded.toByteArray(StandardCharsets.UTF_8))
        } ?: throw IllegalStateException("Unable to open backup destination")
    }

    suspend fun restoreFullBackupFromUri(uri: Uri) = withContext(Dispatchers.IO) {
        val raw = context.contentResolver.openInputStream(uri)?.use { input ->
            input.readBytes().toString(StandardCharsets.UTF_8)
        } ?: throw IllegalStateException("Unable to read backup file")

        val payload = json.decodeFromString<FullBackupPayload>(raw)
        val idMap = mutableMapOf<Long, Long>()

        for (conv in payload.conversations) {
            val newId = conversationDao.insert(
                ConversationEntity(
                    title = conv.title,
                    isPinned = conv.isPinned,
                    customSystemPrompt = conv.customSystemPrompt,
                    createdAt = conv.createdAt,
                    updatedAt = conv.updatedAt
                )
            )
            idMap[conv.id] = newId
        }

        for (msg in payload.messages) {
            val mappedConvId = idMap[msg.conversationId] ?: continue
            messageDao.insert(
                MessageEntity(
                    conversationId = mappedConvId,
                    role = msg.role,
                    content = msg.content,
                    modelUsed = msg.modelUsed,
                    groundingSourcesJson = msg.groundingSourcesJson,
                    createdAt = msg.createdAt
                )
            )
        }

        val existingFacts = memoryDao.getAllOnce().map { it.fact.trim().lowercase() }.toMutableSet()
        for (mem in payload.memories) {
            val key = mem.fact.trim().lowercase()
            if (key.isNotEmpty() && existingFacts.add(key)) {
                memoryDao.insert(
                    MemoryFactEntity(
                        category = mem.category,
                        fact = mem.fact,
                        createdAt = mem.createdAt,
                        updatedAt = mem.updatedAt
                    )
                )
            }
        }
    }
}
