package com.selamai.assistant.ui.memory

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.selamai.assistant.data.repository.MemoryRepository
import com.selamai.assistant.domain.model.MemoryCategory
import com.selamai.assistant.domain.model.MemoryFact
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MemoryViewModel @Inject constructor(
    private val memoryRepository: MemoryRepository
) : ViewModel() {

    val memories: StateFlow<List<MemoryFact>> = memoryRepository.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun addMemory(category: MemoryCategory, fact: String) {
        viewModelScope.launch { memoryRepository.addIfUnique(category, fact) }
    }

    fun updateMemory(id: Long, category: MemoryCategory, fact: String) {
        viewModelScope.launch { memoryRepository.update(id, category, fact) }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch { memoryRepository.delete(id) }
    }
}
