package com.selamai.assistant.domain.util

import com.selamai.assistant.domain.model.Message
import com.selamai.assistant.domain.model.MessageErrorType
import com.selamai.assistant.domain.model.MessageRole

data class WindowedHistory(
    val messages: List<Message>,
    val droppedSummary: String?
)

/**
 * Selects a token-budgeted window of recent messages for Gemini API requests.
 * Guarantees:
 * - Error-only assistant messages are excluded.
 * - The final message in the window is always a USER turn.
 * - Dropped older turns are condensed into a brief summary string so context is preserved.
 */
object TokenBudgetWindow {

    const val DEFAULT_MAX_TOKENS = 12_000

    fun estimateTokens(text: String): Int {
        val ethiopicCount = text.count { it in '\u1200'..'\u137F' }
        val otherCount = text.length - ethiopicCount
        return (ethiopicCount / 2) + (otherCount / 4) + 8
    }

    fun selectWindow(
        allMessages: List<Message>,
        maxTokens: Int = DEFAULT_MAX_TOKENS
    ): WindowedHistory {
        val valid = allMessages.filter { msg ->
            msg.errorType == MessageErrorType.NONE &&
                (msg.content.isNotBlank() || msg.attachmentPath != null)
        }
        if (valid.isEmpty()) return WindowedHistory(emptyList(), null)

        val trimmedEnd = valid.dropLastWhile { it.role != MessageRole.USER }
        if (trimmedEnd.isEmpty()) return WindowedHistory(emptyList(), null)

        val selectedReversed = mutableListOf<Message>()
        var usedTokens = 0

        for (i in trimmedEnd.lastIndex downTo 0) {
            val msg = trimmedEnd[i]
            val msgTokens = estimateTokens(msg.content) + if (msg.attachmentPath != null) 256 else 0
            if (selectedReversed.isEmpty() || usedTokens + msgTokens <= maxTokens) {
                selectedReversed.add(msg)
                usedTokens += msgTokens
            } else {
                break
            }
        }

        val selected = selectedReversed.asReversed()
        val droppedCount = trimmedEnd.size - selected.size
        val summary = if (droppedCount > 0) {
            val older = trimmedEnd.take(droppedCount)
            val snippets = older.takeLast(4).joinToString(" | ") { m ->
                val prefix = if (m.role == MessageRole.USER) "User" else "Assistant"
                val cleanText = m.content.replace("\n", " ").take(90)
                "$prefix: $cleanText"
            }
            "Earlier in this conversation ($droppedCount older messages omitted for token budget): $snippets"
        } else {
            null
        }

        return WindowedHistory(messages = selected, droppedSummary = summary)
    }
}
