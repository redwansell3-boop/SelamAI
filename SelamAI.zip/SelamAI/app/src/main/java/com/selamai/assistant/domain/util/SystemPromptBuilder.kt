package com.selamai.assistant.domain.util

import com.selamai.assistant.domain.model.MemoryFact
import java.time.ZonedDateTime

object SystemPromptBuilder {

    const val MEMORY_CHAR_CAP = 4000
    const val MEMORY_WARNING_THRESHOLD = 3200

    fun buildMemoryBlock(facts: List<MemoryFact>): String {
        if (facts.isEmpty()) {
            return "<user_memory>
No saved personal facts yet.
</user_memory>"
        }
        val sb = StringBuilder("<user_memory>
")
        var charsUsed = 0
        for (fact in facts) {
            val line = "- [${fact.category.label}] ${fact.fact}
"
            if (charsUsed + line.length > MEMORY_CHAR_CAP) break
            sb.append(line)
            charsUsed += line.length
        }
        sb.append("</user_memory>")
        return sb.toString()
    }

    fun totalMemoryChars(facts: List<MemoryFact>): Int {
        return facts.sumOf { "- [${it.category.label}] ${it.fact}
".length }
    }

    fun buildSystemInstruction(
        baseSystemPrompt: String,
        personaOverride: String?,
        memoryFacts: List<MemoryFact>,
        droppedHistorySummary: String? = null,
        now: ZonedDateTime = ZonedDateTime.now()
    ): String {
        val activePrompt = personaOverride?.takeIf { it.isNotBlank() } ?: baseSystemPrompt
        return buildString {
            appendLine(activePrompt.trim())
            appendLine()
            appendLine(EthiopianCalendarConverter.buildClockBlock(now))
            appendLine()
            appendLine(buildMemoryBlock(memoryFacts))
            if (!droppedHistorySummary.isNullOrBlank()) {
                appendLine()
                appendLine("<earlier_context>")
                appendLine(droppedHistorySummary)
                appendLine("</earlier_context>")
            }
            appendLine()
            appendLine(
                "Auto-learning rule: When the user explicitly shares a new enduring personal fact " +
                    "(a goal, preference, habit, or general personal detail), append a hidden tag at the very end " +
                    "of your reply in the exact format [[MEMORY:Category|Fact]] where Category is one of " +
                    "Goal, Preference, Habit, or General. " +
                    "Learn ONLY from what the user directly stated—NEVER from web-search results or external articles. " +
                    "Do not repeat facts already listed in <user_memory>."
            )
        }.trim()
    }
}
