package com.selamai.assistant.data.local

import android.content.Context
import android.util.Base64
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.google.crypto.tink.Aead
import com.google.crypto.tink.KeyTemplates
import com.google.crypto.tink.aead.AeadConfig
import com.google.crypto.tink.integration.android.AndroidKeysetManager
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.nio.charset.StandardCharsets
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Stores the Gemini API key encrypted with AES-256-GCM backed by Android Keystore
 * using Google Tink + Jetpack DataStore (no deprecated EncryptedSharedPreferences).
 */
@Singleton
class EncryptedApiKeyStore @Inject constructor(
    @ApplicationContext private val context: Context,
    private val dataStore: DataStore<Preferences>
) {
    companion object {
        private const val KEYSET_NAME = "selamai_tink_keyset"
        private const val PREF_FILE_NAME = "selamai_tink_keyset_prefs"
        private const val MASTER_KEY_URI = "android-keystore://selamai_master_key_v1"
        private val ASSOCIATED_DATA = "selamai_gemini_api_key".toByteArray(StandardCharsets.UTF_8)
        private val KEY_ENCRYPTED_API_KEY = stringPreferencesKey("encrypted_gemini_api_key")
    }

    private val aead: Aead by lazy {
        AeadConfig.register()
        AndroidKeysetManager.Builder()
            .withSharedPref(context, KEYSET_NAME, PREF_FILE_NAME)
            .withKeyTemplate(KeyTemplates.get("AES256_GCM"))
            .withMasterKeyUri(MASTER_KEY_URI)
            .build()
            .keysetHandle
            .getPrimitive(Aead::class.java)
    }

    val hasApiKeyFlow: Flow<Boolean> = dataStore.data.map { prefs ->
        !prefs[KEY_ENCRYPTED_API_KEY].isNullOrBlank()
    }

    suspend fun saveApiKey(rawKey: String) {
        val trimmed = rawKey.trim()
        dataStore.edit { prefs ->
            if (trimmed.isEmpty()) {
                prefs.remove(KEY_ENCRYPTED_API_KEY)
            } else {
                val ciphertext = aead.encrypt(
                    trimmed.toByteArray(StandardCharsets.UTF_8),
                    ASSOCIATED_DATA
                )
                prefs[KEY_ENCRYPTED_API_KEY] = Base64.encodeToString(ciphertext, Base64.NO_WRAP)
            }
        }
    }

    suspend fun getApiKey(): String? {
        val encoded = dataStore.data.first()[KEY_ENCRYPTED_API_KEY] ?: return null
        return runCatching {
            val bytes = Base64.decode(encoded, Base64.NO_WRAP)
            String(aead.decrypt(bytes, ASSOCIATED_DATA), StandardCharsets.UTF_8)
        }.getOrNull()
    }

    suspend fun clearApiKey() {
        dataStore.edit { it.remove(KEY_ENCRYPTED_API_KEY) }
    }
}
