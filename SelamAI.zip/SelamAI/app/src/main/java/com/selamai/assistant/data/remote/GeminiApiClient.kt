package com.selamai.assistant.data.remote

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.selamai.assistant.domain.model.GroundingSource
import com.selamai.assistant.domain.model.MessageErrorType
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets
import javax.inject.Inject
import javax.inject.Singleton

sealed class GeminiStreamEvent {
    data class ModelSelected(val model: String) : GeminiStreamEvent()
    data class TextDelta(val text: String) : GeminiStreamEvent()
    data class GroundingSources(val sources: List<GroundingSource>) : GeminiStreamEvent()
    data class Completed(val model: String, val finishReason: String?) : GeminiStreamEvent()
    data class Failed(
        val errorType: MessageErrorType,
        val detail: String? = null,
        val model: String? = null
    ) : GeminiStreamEvent()
}

@Singleton
class GeminiApiClient @Inject constructor(
    @ApplicationContext private val context: Context,
    private val okHttpClient: OkHttpClient,
    private val json: Json
) {
    companion object {
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    }

    private val fallbackExecutor = GeminiFallbackExecutor()

    fun isNetworkAvailable(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return true
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun thinkingLevelForModel(model: String): String {
        val lower = model.lowercase()
        return when {
            lower.contains("hydrogen") || lower.contains("pro") -> "LOW"
            else -> "MINIMAL"
        }
    }

    fun streamGenerateContent(
        apiKey: String,
        selectedModel: String,
        fallbackModels: List<String>,
        systemInstruction: String,
        contents: List<GeminiContent>,
        enableGoogleSearch: Boolean
    ): Flow<GeminiStreamEvent> = callbackFlow {
        var activeCall: Call? = null

        val job = launch(Dispatchers.IO) {
            if (!isNetworkAvailable()) {
                trySend(GeminiStreamEvent.Failed(MessageErrorType.NO_NETWORK))
                close()
                return@launch
            }

            try {
                val result = fallbackExecutor.execute(
                    selectedModel = selectedModel,
                    fallbackModels = fallbackModels
                ) { model ->
                    val requestPayload = GeminiGenerateRequest(
                        systemInstruction = GeminiContent(
                            parts = listOf(GeminiPart(text = systemInstruction))
                        ),
                        contents = contents,
                        tools = if (enableGoogleSearch) listOf(GeminiTool()) else null,
                        generationConfig = GeminiGenerationConfig(
                            thinkingConfig = GeminiThinkingConfig(
                                thinkingLevel = thinkingLevelForModel(model)
                            )
                        )
                    )
                    val bodyJson = json.encodeToString(requestPayload)
                    val url = "$BASE_URL/$model:streamGenerateContent?alt=sse"
                    val request = Request.Builder()
                        .url(url)
                        .addHeader("x-goog-api-key", apiKey)
                        .addHeader("Accept", "text/event-stream")
                        .post(bodyJson.toRequestBody(JSON_MEDIA_TYPE))
                        .build()

                    val call = okHttpClient.newCall(request)
                    activeCall = call
                    val response = call.execute()

                    if (!response.isSuccessful) {
                        val code = response.code
                        val retryAfter = response.header("Retry-After")
                        val errMsg = response.body?.string()?.take(300)
                        response.close()
                        ModelAttemptOutcome.HttpError(
                            statusCode = code,
                            retryAfterHeader = retryAfter,
                            message = errMsg
                        )
                    } else {
                        ModelAttemptOutcome.Success(model = model, value = response)
                    }
                }

                when (result) {
                    is FallbackResult.InvalidApiKey -> {
                        trySend(
                            GeminiStreamEvent.Failed(
                                errorType = MessageErrorType.INVALID_API_KEY,
                                detail = result.message
                            )
                        )
                    }
                    is FallbackResult.RateLimitOrDemandExhausted -> {
                        trySend(
                            GeminiStreamEvent.Failed(
                                errorType = MessageErrorType.RATE_LIMIT,
                                detail = "HTTP ${result.lastStatusCode}"
                            )
                        )
                    }
                    is FallbackResult.OtherError -> {
                        trySend(
                            GeminiStreamEvent.Failed(
                                errorType = MessageErrorType.UNKNOWN,
                                detail = "HTTP ${result.statusCode}: ${result.message.orEmpty()}"
                            )
                        )
                    }
                    is FallbackResult.Success -> {
                        val modelUsed = result.model
                        trySend(GeminiStreamEvent.ModelSelected(modelUsed))
                        val response = result.value
                        response.use { resp ->
                            val bodyStream = resp.body?.byteStream()
                            if (bodyStream == null) {
                                trySend(GeminiStreamEvent.Failed(MessageErrorType.EMPTY_RESPONSE, model = modelUsed))
                                return@launch
                            }

                            val reader = BufferedReader(InputStreamReader(bodyStream, StandardCharsets.UTF_8))
                            var receivedAnyText = false
                            var lastFinishReason: String? = null
                            val collectedSources = LinkedHashMap<String, GroundingSource>()

                            while (isActive) {
                                val line = reader.readLine() ?: break
                                if (!line.startsWith("data:")) continue
                                val data = line.removePrefix("data:").trim()
                                if (data.isEmpty() || data == "[DONE]") continue

                                val chunk = runCatching {
                                    json.decodeFromString<GeminiStreamChunk>(data)
                                }.getOrNull() ?: continue

                                val blockReason = chunk.promptFeedback?.blockReason
                                if (!blockReason.isNullOrBlank()) {
                                    trySend(
                                        GeminiStreamEvent.Failed(
                                            errorType = MessageErrorType.SAFETY_BLOCK,
                                            detail = blockReason,
                                            model = modelUsed
                                        )
                                    )
                                    return@launch
                                }

                                val candidate = chunk.candidates?.firstOrNull() ?: continue
                                candidate.finishReason?.let { lastFinishReason = it }

                                candidate.content?.parts?.forEach { part ->
                                    val delta = part.text
                                    if (!delta.isNullOrEmpty()) {
                                        receivedAnyText = true
                                        trySend(GeminiStreamEvent.TextDelta(delta))
                                    }
                                }

                                candidate.groundingMetadata?.groundingChunks?.forEach { gChunk ->
                                    val uri = gChunk.web?.uri
                                    if (!uri.isNullOrBlank()) {
                                        val title = gChunk.web.title?.takeIf { it.isNotBlank() } ?: uri
                                        collectedSources[uri] = GroundingSource(title = title, uri = uri)
                                    }
                                }
                            }

                            if (collectedSources.isNotEmpty()) {
                                trySend(GeminiStreamEvent.GroundingSources(collectedSources.values.toList()))
                            }

                            when (lastFinishReason) {
                                "SAFETY", "RECITATION", "BLOCKLIST", "PROHIBITED_CONTENT" -> {
                                    trySend(
                                        GeminiStreamEvent.Failed(
                                            errorType = MessageErrorType.SAFETY_BLOCK,
                                            detail = lastFinishReason,
                                            model = modelUsed
                                        )
                                    )
                                }
                                "MAX_TOKENS" -> {
                                    trySend(
                                        GeminiStreamEvent.Failed(
                                            errorType = MessageErrorType.MAX_TOKENS,
                                            detail = lastFinishReason,
                                            model = modelUsed
                                        )
                                    )
                                }
                                else -> {
                                    if (!receivedAnyText) {
                                        trySend(
                                            GeminiStreamEvent.Failed(
                                                errorType = MessageErrorType.EMPTY_RESPONSE,
                                                model = modelUsed
                                            )
                                        )
                                    } else {
                                        trySend(GeminiStreamEvent.Completed(modelUsed, lastFinishReason))
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (ioe: IOException) {
                if (isActive) {
                    val errType = if (!isNetworkAvailable()) {
                        MessageErrorType.NO_NETWORK
                    } else {
                        MessageErrorType.STREAM_INTERRUPTED
                    }
                    trySend(GeminiStreamEvent.Failed(errType, detail = ioe.message))
                }
            } catch (e: Exception) {
                if (isActive) {
                    trySend(GeminiStreamEvent.Failed(MessageErrorType.UNKNOWN, detail = e.message))
                }
            } finally {
                close()
            }
        }

        awaitClose {
            activeCall?.cancel()
            job.cancel()
        }
    }
}
