package com.selamai.assistant.domain.model

import kotlinx.serialization.Serializable

enum class MessageRole {
    USER,
    ASSISTANT
}

enum class AttachmentType {
    IMAGE,
    PDF
}

@Serializable
data class GroundingSource(
    val title: String,
    val uri: String
)

enum class MessageErrorType {
    NONE,
    NO_NETWORK,
    MISSING_API_KEY,
    INVALID_API_KEY,
    RATE_LIMIT,
    SAFETY_BLOCK,
    MAX_TOKENS,
    EMPTY_RESPONSE,
    STREAM_INTERRUPTED,
    UNKNOWN
}

data class Conversation(
    val id: Long = 0L,
    val title: String,
    val isPinned: Boolean = false,
    val customSystemPrompt: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class Message(
    val id: Long = 0L,
    val conversationId: Long,
    val role: MessageRole,
    val content: String,
    val modelUsed: String? = null,
    val attachmentPath: String? = null,
    val attachmentMimeType: String? = null,
    val attachmentName: String? = null,
    val attachmentType: AttachmentType? = null,
    val groundingSources: List<GroundingSource> = emptyList(),
    val errorType: MessageErrorType = MessageErrorType.NONE,
    val errorDetail: String? = null,
    val isPartial: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

enum class MemoryCategory(val label: String) {
    GOAL("Goal"),
    PREFERENCE("Preference"),
    HABIT("Habit"),
    GENERAL("General");

    companion object {
        fun fromString(raw: String): MemoryCategory {
            val normalized = raw.trim().lowercase()
            return entries.firstOrNull { it.label.lowercase() == normalized } ?: GENERAL
        }
    }
}

data class MemoryFact(
    val id: Long = 0L,
    val category: MemoryCategory,
    val fact: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}

data class AppSettings(
    val defaultModel: String = DEFAULT_MODEL,
    val fallbackModels: List<String> = DEFAULT_FALLBACK_CHAIN,
    val liveWebSearchEnabled: Boolean = true,
    val defaultSystemPrompt: String = DEFAULT_SYSTEM_PROMPT,
    val askBeforeSavingMemory: Boolean = true,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColorEnabled: Boolean = true,
    val appLanguage: String = "en",
    val biometricLockEnabled: Boolean = false
) {
    companion object {
        const val DEFAULT_MODEL = "gemini-3.5-flash-lite"
        val DEFAULT_FALLBACK_CHAIN = listOf("gemini-3.8-flash", "gemini-4-hydrogen")
        const val DEFAULT_SYSTEM_PROMPT =
            "You are SelamAI, a concise, warm, direct personal AI assistant fluent in Amharic and English. " +
                "Reply strictly in the user's language without repeating English translations. " +
                "Be helpful, grounded, and respectful."
    }
}

data class PendingShare(
    val text: String? = null,
    val imageUriString: String? = null
)
