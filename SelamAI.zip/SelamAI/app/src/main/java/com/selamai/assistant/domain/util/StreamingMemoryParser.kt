package com.selamai.assistant.domain.util

import com.selamai.assistant.domain.model.MemoryCategory

data class ParsedMemoryCandidate(
    val category: MemoryCategory,
    val fact: String
)

data class StreamChunkResult(
    val visibleTextDelta: String,
    val extractedMemories: List<ParsedMemoryCandidate>
)

/**
 * Streaming-safe parser for auto-learned memory tags of the form:
 *   [[MEMORY:Category|Fact]]
 *
 * Buffers potential partial tag prefixes at chunk boundaries so that
 * partial tags like "[" or "[[MEM" never appear in the visible chat bubble.
 */
class StreamingMemoryParser {

    companion object {
        private const val TAG_PREFIX = "[[MEMORY:"
        private const val TAG_SUFFIX = "]]"
    }

    private val pendingBuffer = StringBuilder()

    fun feed(chunk: String): StreamChunkResult {
        if (chunk.isEmpty()) {
            return StreamChunkResult("", emptyList())
        }
        pendingBuffer.append(chunk)
        val visible = StringBuilder()
        val memories = mutableListOf<ParsedMemoryCandidate>()

        while (pendingBuffer.isNotEmpty()) {
            val current = pendingBuffer.toString()
            val startIdx = current.indexOf(TAG_PREFIX)

            if (startIdx >= 0) {
                // Emit everything before the tag start
                if (startIdx > 0) {
                    visible.append(current.substring(0, startIdx))
                    pendingBuffer.delete(0, startIdx)
                }
                val afterStart = pendingBuffer.toString()
                val endIdx = afterStart.indexOf(TAG_SUFFIX, startIndex = TAG_PREFIX.length)
                if (endIdx >= 0) {
                    val inner = afterStart.substring(TAG_PREFIX.length, endIdx)
                    parseTagPayload(inner)?.let { memories.add(it) }
                    pendingBuffer.delete(0, endIdx + TAG_SUFFIX.length)
                    continue
                } else {
                    // Tag started but not yet closed; wait for more chunks
                    break
                }
            } else {
                // No full TAG_PREFIX yet; check if suffix of pendingBuffer is a prefix of TAG_PREFIX
                val holdBack = longestPrefixMatchAtEnd(current, TAG_PREFIX)
                val safeLength = current.length - holdBack
                if (safeLength > 0) {
                    visible.append(current.substring(0, safeLength))
                    pendingBuffer.delete(0, safeLength)
                }
                break
            }
        }

        return StreamChunkResult(
            visibleTextDelta = visible.toString(),
            extractedMemories = memories
        )
    }

    /**
     * Call when the stream finishes to flush any buffered non-tag text (e.g., a stray "[").
     * Incomplete [[MEMORY:... tags without closing "]]" are discarded so they never leak.
     */
    fun flush(): StreamChunkResult {
        val remaining = pendingBuffer.toString()
        pendingBuffer.clear()
        return if (remaining.startsWith(TAG_PREFIX)) {
            StreamChunkResult("", emptyList())
        } else {
            StreamChunkResult(remaining, emptyList())
        }
    }

    fun reset() {
        pendingBuffer.clear()
    }

    private fun parseTagPayload(inner: String): ParsedMemoryCandidate? {
        val pipeIdx = inner.indexOf('|')
        if (pipeIdx <= 0 || pipeIdx >= inner.lastIndex) return null
        val rawCategory = inner.substring(0, pipeIdx).trim()
        val fact = inner.substring(pipeIdx + 1).trim()
        if (fact.isBlank()) return null
        return ParsedMemoryCandidate(
            category = MemoryCategory.fromString(rawCategory),
            fact = fact
        )
    }

    private fun longestPrefixMatchAtEnd(text: String, prefix: String): Int {
        val maxLen = minOf(text.length, prefix.length - 1)
        for (len in maxLen downTo 1) {
            if (text.regionMatches(text.length - len, prefix, 0, len)) {
                return len
            }
        }
        return 0
    }
}
