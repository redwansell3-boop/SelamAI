package com.selamai.assistant.data.remote

import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.pow
import kotlin.random.Random

sealed class ModelAttemptOutcome<out T> {
    data class Success<T>(val model: String, val value: T) : ModelAttemptOutcome<T>()
    data class HttpError(
        val statusCode: Int,
        val retryAfterHeader: String? = null,
        val message: String? = null
    ) : ModelAttemptOutcome<Nothing>()
}

sealed class FallbackResult<out T> {
    data class Success<T>(val model: String, val value: T) : FallbackResult<T>()
    data class InvalidApiKey(val statusCode: Int, val message: String?) : FallbackResult<Nothing>()
    data class RateLimitOrDemandExhausted(val lastStatusCode: Int, val triedModels: List<String>) :
        FallbackResult<Nothing>()
    data class OtherError(val statusCode: Int, val message: String?) : FallbackResult<Nothing>()
}

/**
 * Implements SelamAI's model fallback & retry policy:
 * - Builds deduplicated model chain: [selectedModel] + fallbackModels (never retries an already-tried model).
 * - HTTP 503: retry same model up to 2 times with exponential backoff + jitter, then move to next model.
 * - HTTP 429: honor Retry-After once, then move to next model. If every model fails -> RateLimitOrDemandExhausted.
 * - HTTP 404: move to next model immediately.
 * - HTTP 400/401/403: NO fallback -> InvalidApiKey immediately.
 */
class GeminiFallbackExecutor(
    private val delayFn: suspend (Long) -> Unit = { kotlinx.coroutines.delay(it) },
    private val jitterProvider: () -> Long = { Random.nextLong(0L, 400L) },
    private val baseBackoffMs: Long = 1000L,
    private val maxRetryAfterMs: Long = 30_000L
) {
    fun buildUniqueModelChain(selectedModel: String, fallbackModels: List<String>): List<String> {
        val seen = LinkedHashSet<String>()
        val trimmedSelected = selectedModel.trim()
        if (trimmedSelected.isNotEmpty()) seen.add(trimmedSelected)
        for (m in fallbackModels) {
            val trimmed = m.trim()
            if (trimmed.isNotEmpty()) seen.add(trimmed)
        }
        return seen.toList()
    }

    fun parseRetryAfterMs(header: String?, nowEpochMs: Long = System.currentTimeMillis()): Long {
        if (header.isNullOrBlank()) return 2_000L
        val trimmed = header.trim()
        trimmed.toLongOrNull()?.let { seconds ->
            return (seconds * 1000L).coerceIn(500L, maxRetryAfterMs)
        }
        return runCatching {
            val targetMs = ZonedDateTime.parse(trimmed, DateTimeFormatter.RFC_1123_DATE_TIME)
                .toInstant()
                .toEpochMilli()
            (targetMs - nowEpochMs).coerceIn(500L, maxRetryAfterMs)
        }.getOrDefault(2_000L)
    }

    suspend fun <T> execute(
        selectedModel: String,
        fallbackModels: List<String>,
        attempt: suspend (model: String) -> ModelAttemptOutcome<T>
    ): FallbackResult<T> {
        val chain = buildUniqueModelChain(selectedModel, fallbackModels)
        val tried = mutableListOf<String>()
        var lastErrorCode = 503
        var sawRateLimitOrDemand = false

        for (model in chain) {
            tried.add(model)
            var retries503 = 0
            var honored429 = false

            while (true) {
                when (val outcome = attempt(model)) {
                    is ModelAttemptOutcome.Success -> {
                        return FallbackResult.Success(model = outcome.model, value = outcome.value)
                    }
                    is ModelAttemptOutcome.HttpError -> {
                        lastErrorCode = outcome.statusCode
                        when (outcome.statusCode) {
                            400, 401, 403 -> {
                                return FallbackResult.InvalidApiKey(
                                    statusCode = outcome.statusCode,
                                    message = outcome.message
                                )
                            }
                            404 -> {
                                // Immediate fallback to next model
                                break
                            }
                            503 -> {
                                sawRateLimitOrDemand = true
                                if (retries503 < 2) {
                                    val backoff = (baseBackoffMs * 2.0.pow(retries503)).toLong() + jitterProvider()
                                    retries503++
                                    delayFn(backoff)
                                    continue
                                } else {
                                    break
                                }
                            }
                            429 -> {
                                sawRateLimitOrDemand = true
                                if (!honored429) {
                                    honored429 = true
                                    val waitMs = parseRetryAfterMs(outcome.retryAfterHeader)
                                    delayFn(waitMs)
                                    continue
                                } else {
                                    break
                                }
                            }
                            else -> {
                                return FallbackResult.OtherError(outcome.statusCode, outcome.message)
                            }
                        }
                    }
                }
            }
        }

        return if (sawRateLimitOrDemand || lastErrorCode == 404) {
            FallbackResult.RateLimitOrDemandExhausted(
                lastStatusCode = lastErrorCode,
                triedModels = tried
            )
        } else {
            FallbackResult.OtherError(lastErrorCode, "All models failed")
        }
    }
}
