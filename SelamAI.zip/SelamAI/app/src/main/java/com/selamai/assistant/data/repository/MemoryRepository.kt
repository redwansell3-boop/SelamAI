package com.selamai.assistant.data.repository

import com.selamai.assistant.data.local.MemoryDao
import com.selamai.assistant.data.local.MemoryFactEntity
import com.selamai.assistant.domain.model.MemoryCategory
import com.selamai.assistant.domain.model.MemoryFact
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MemoryRepository @Inject constructor(
    private val memoryDao: MemoryDao
) {
    fun observeAll(): Flow<List<MemoryFact>> = memoryDao.observeAll().map { list ->
        list.map { it.toDomain() }
    }

    suspend fun getAllOnce(): List<MemoryFact> = memoryDao.getAllOnce().map { it.toDomain() }

    suspend fun isDuplicate(fact: String): Boolean {
        val normalized = normalize(fact)
        if (normalized.isEmpty()) return true
        return memoryDao.getAllOnce().any { normalize(it.fact) == normalized }
    }

    /**
     * Adds a memory fact if not already present (case-insensitive normalized deduplication).
     * Returns true if inserted, false if duplicate.
     */
    suspend fun addIfUnique(category: MemoryCategory, fact: String): Boolean {
        val trimmed = fact.trim()
        if (trimmed.isEmpty() || isDuplicate(trimmed)) return false
        val now = System.currentTimeMillis()
        memoryDao.insert(
            MemoryFactEntity(
                category = category.label,
                fact = trimmed,
                createdAt = now,
                updatedAt = now
            )
        )
        return true
    }

    suspend fun update(id: Long, category: MemoryCategory, fact: String) {
        val trimmed = fact.trim()
        if (trimmed.isEmpty()) return
        val existing = memoryDao.getAllOnce().firstOrNull { it.id == id } ?: return
        memoryDao.update(
            existing.copy(
                category = category.label,
                fact = trimmed,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun delete(id: Long) {
        memoryDao.deleteById(id)
    }

    private fun normalize(text: String): String =
        text.trim().lowercase().replace(Regex("\s+"), " ")

    private fun MemoryFactEntity.toDomain() = MemoryFact(
        id = id,
        category = MemoryCategory.fromString(category),
        fact = fact,
        createdAt = createdAt,
        updatedAt = updatedAt
    )
}
