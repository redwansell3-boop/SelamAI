package com.selamai.assistant.di

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.Room
import com.selamai.assistant.data.local.ConversationDao
import com.selamai.assistant.data.local.MemoryDao
import com.selamai.assistant.data.local.MessageDao
import com.selamai.assistant.data.local.SelamDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

private val Context.selamDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "selamai_settings"
)

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideJson(): Json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        explicitNulls = false
    }

    @Provides
    @Singleton
    fun provideDataStore(@ApplicationContext context: Context): DataStore<Preferences> =
        context.selamDataStore

    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient {
        // Security: Never attach HTTP header/body logging interceptors so API keys are never logged.
        return OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(0, TimeUnit.SECONDS) // Required for long-lived SSE streaming
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): SelamDatabase {
        return Room.databaseBuilder(
            context,
            SelamDatabase::class.java,
            "selamai.db"
        ).fallbackToDestructiveMigration().build()
    }

    @Provides
    fun provideConversationDao(db: SelamDatabase): ConversationDao = db.conversationDao()

    @Provides
    fun provideMessageDao(db: SelamDatabase): MessageDao = db.messageDao()

    @Provides
    fun provideMemoryDao(db: SelamDatabase): MemoryDao = db.memoryDao()
}
