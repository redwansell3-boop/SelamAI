package com.selamai.assistant.domain.util

sealed class MarkdownBlock {
    data class Heading(val level: Int, val spans: List<MarkdownSpan>) : MarkdownBlock()
    data class Paragraph(val spans: List<MarkdownSpan>) : MarkdownBlock()
    data class CodeBlock(val language: String?, val code: String) : MarkdownBlock()
    data class BulletItem(val spans: List<MarkdownSpan>) : MarkdownBlock()
    data class NumberedItem(val number: Int, val spans: List<MarkdownSpan>) : MarkdownBlock()
    data class Blockquote(val spans: List<MarkdownSpan>) : MarkdownBlock()
}

sealed class MarkdownSpan {
    data class Plain(val text: String) : MarkdownSpan()
    data class Bold(val text: String) : MarkdownSpan()
    data class Italic(val text: String) : MarkdownSpan()
    data class InlineCode(val code: String) : MarkdownSpan()
    data class Link(val label: String, val url: String) : MarkdownSpan()
}

/**
 * Lightweight, pure-Kotlin Markdown parser supporting:
 * headings, bold, italic, inline code, fenced code blocks,
 * bullet lists, numbered lists, links, and blockquotes.
 */
object MarkdownParser {

    private val headingRegex = Regex("^(#{1,6})\\s+(.*)$")
    private val bulletRegex = Regex("^\\s*[-*•]\\s+(.*)$")
    private val numberedRegex = Regex("^\\s*(\\d+)\\.\\s+(.*)$")
    private val blockquoteRegex = Regex("^>\\s?(.*)$")

    private val inlineRegex = Regex(
        "`([^`]+)`|\\[([^\\]]+)]\\((https?://[^)\\s]+)\\)|\\*\\*([^*]+)\\*\\*|__([^_]+)__|(?<!\\*)\\*([^*]+)\\*(?!\\*)|(?<!_)_([^_]+)_(?!_)"
    )

    fun parse(markdown: String): List<MarkdownBlock> {
        if (markdown.isEmpty()) return emptyList()
        val lines = markdown.replace("\r\n", "\n").split("\n")
        val blocks = mutableListOf<MarkdownBlock>()
        var i = 0

        while (i < lines.size) {
            val line = lines[i]
            val trimmed = line.trim()

            if (trimmed.startsWith("```")) {
                val lang = trimmed.removePrefix("```").trim().ifEmpty { null }
                val codeLines = mutableListOf<String>()
                i++
                while (i < lines.size && !lines[i].trim().startsWith("```")) {
                    codeLines.add(lines[i])
                    i++
                }
                if (i < lines.size) i++
                blocks.add(MarkdownBlock.CodeBlock(lang, codeLines.joinToString("\n")))
                continue
            }

            if (trimmed.isEmpty()) {
                i++
                continue
            }

            val headingMatch = headingRegex.matchEntire(trimmed)
            if (headingMatch != null) {
                val level = headingMatch.groupValues[1].length.coerceIn(1, 3)
                val text = headingMatch.groupValues[2].trim()
                blocks.add(MarkdownBlock.Heading(level, parseInline(text)))
                i++
                continue
            }

            val quoteMatch = blockquoteRegex.matchEntire(trimmed)
            if (quoteMatch != null) {
                val quoteLines = mutableListOf<String>()
                while (i < lines.size) {
                    val m = blockquoteRegex.matchEntire(lines[i].trim()) ?: break
                    quoteLines.add(m.groupValues[1])
                    i++
                }
                blocks.add(MarkdownBlock.Blockquote(parseInline(quoteLines.joinToString("\n"))))
                continue
            }

            val bulletMatch = bulletRegex.matchEntire(line)
            if (bulletMatch != null) {
                blocks.add(MarkdownBlock.BulletItem(parseInline(bulletMatch.groupValues[1].trim())))
                i++
                continue
            }

            val numMatch = numberedRegex.matchEntire(line)
            if (numMatch != null) {
                val num = numMatch.groupValues[1].toIntOrNull() ?: 1
                blocks.add(MarkdownBlock.NumberedItem(num, parseInline(numMatch.groupValues[2].trim())))
                i++
                continue
            }

            val paraLines = mutableListOf<String>()
            while (i < lines.size) {
                val current = lines[i]
                val t = current.trim()
                if (t.isEmpty() ||
                    t.startsWith("```") ||
                    headingRegex.matches(t) ||
                    blockquoteRegex.matches(t) ||
                    bulletRegex.matches(current) ||
                    numberedRegex.matches(current)
                ) {
                    break
                }
                paraLines.add(current)
                i++
            }
            if (paraLines.isNotEmpty()) {
                blocks.add(MarkdownBlock.Paragraph(parseInline(paraLines.joinToString("\n"))))
            }
        }
        return blocks
    }

    fun parseInline(text: String): List<MarkdownSpan> {
        if (text.isEmpty()) return emptyList()
        val spans = mutableListOf<MarkdownSpan>()
        var cursor = 0

        for (match in inlineRegex.findAll(text)) {
            if (match.range.first > cursor) {
                spans.add(MarkdownSpan.Plain(text.substring(cursor, match.range.first)))
            }
            when {
                match.groups[1] != null -> spans.add(MarkdownSpan.InlineCode(match.groupValues[1]))
                match.groups[2] != null && match.groups[3] != null ->
                    spans.add(MarkdownSpan.Link(match.groupValues[2], match.groupValues[3]))
                match.groups[4] != null -> spans.add(MarkdownSpan.Bold(match.groupValues[4]))
                match.groups[5] != null -> spans.add(MarkdownSpan.Bold(match.groupValues[5]))
                match.groups[6] != null -> spans.add(MarkdownSpan.Italic(match.groupValues[6]))
                match.groups[7] != null -> spans.add(MarkdownSpan.Italic(match.groupValues[7]))
            }
            cursor = match.range.last + 1
        }

        if (cursor < text.length) {
            spans.add(MarkdownSpan.Plain(text.substring(cursor)))
        }
        return spans
    }
}
