package com.selamai.assistant.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.selamai.assistant.domain.util.MarkdownBlock
import com.selamai.assistant.domain.util.MarkdownParser
import com.selamai.assistant.domain.util.MarkdownSpan

@Composable
fun MarkdownText(
    markdown: String,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    val blocks = remember(markdown) { MarkdownParser.parse(markdown) }
    val linkColor = MaterialTheme.colorScheme.primary
    val codeBg = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f)
    val uriHandler = LocalUriHandler.current
    val clipboard = LocalClipboardManager.current

    SelectionContainer(modifier = modifier) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            blocks.forEach { block ->
                when (block) {
                    is MarkdownBlock.Heading -> {
                        val style = when (block.level) {
                            1 -> MaterialTheme.typography.titleLarge
                            2 -> MaterialTheme.typography.titleMedium
                            else -> MaterialTheme.typography.titleSmall
                        }.copy(color = textColor)
                        SpanText(block.spans, style, linkColor, codeBg) { url ->
                            runCatching { uriHandler.openUri(url) }
                        }
                    }

                    is MarkdownBlock.Paragraph -> {
                        SpanText(
                            spans = block.spans,
                            style = MaterialTheme.typography.bodyLarge.copy(color = textColor),
                            linkColor = linkColor,
                            codeBg = codeBg
                        ) { url -> runCatching { uriHandler.openUri(url) } }
                    }

                    is MarkdownBlock.BulletItem -> {
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "• ",
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    color = textColor,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            SpanText(
                                spans = block.spans,
                                style = MaterialTheme.typography.bodyLarge.copy(color = textColor),
                                linkColor = linkColor,
                                codeBg = codeBg,
                                modifier = Modifier.weight(1f)
                            ) { url -> runCatching { uriHandler.openUri(url) } }
                        }
                    }

                    is MarkdownBlock.NumberedItem -> {
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "${block.number}. ",
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    color = textColor,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            SpanText(
                                spans = block.spans,
                                style = MaterialTheme.typography.bodyLarge.copy(color = textColor),
                                linkColor = linkColor,
                                codeBg = codeBg,
                                modifier = Modifier.weight(1f)
                            ) { url -> runCatching { uriHandler.openUri(url) } }
                        }
                    }

                    is MarkdownBlock.Blockquote -> {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(IntrinsicSize.Min)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
                                .padding(end = 10.dp, top = 6.dp, bottom = 6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(4.dp)
                                    .fillMaxHeight()
                                    .background(MaterialTheme.colorScheme.primary)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            SpanText(
                                spans = block.spans,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = textColor.copy(alpha = 0.9f),
                                    fontStyle = FontStyle.Italic
                                ),
                                linkColor = linkColor,
                                codeBg = codeBg,
                                modifier = Modifier.weight(1f)
                            ) { url -> runCatching { uriHandler.openUri(url) } }
                        }
                    }

                    is MarkdownBlock.CodeBlock -> {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerHighest,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = block.language ?: "code",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    IconButton(
                                        onClick = {
                                            clipboard.setText(AnnotatedString(block.code))
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ContentCopy,
                                            contentDescription = "Copy code",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Text(
                                    text = block.code,
                                    style = TextStyle(
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 13.sp,
                                        lineHeight = 18.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState())
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Suppress("DEPRECATION")
@Composable
private fun SpanText(
    spans: List<MarkdownSpan>,
    style: TextStyle,
    linkColor: Color,
    codeBg: Color,
    modifier: Modifier = Modifier,
    onLinkClick: (String) -> Unit
) {
    val annotated = remember(spans, linkColor, codeBg) {
        buildAnnotatedString {
            spans.forEach { span ->
                when (span) {
                    is MarkdownSpan.Plain -> append(span.text)
                    is MarkdownSpan.Bold -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                        append(span.text)
                    }
                    is MarkdownSpan.Italic -> withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                        append(span.text)
                    }
                    is MarkdownSpan.InlineCode -> withStyle(
                        SpanStyle(
                            fontFamily = FontFamily.Monospace,
                            background = codeBg,
                            fontSize = 13.sp
                        )
                    ) {
                        append(" ${span.code} ")
                    }
                    is MarkdownSpan.Link -> {
                        val start = length
                        withStyle(
                            SpanStyle(
                                color = linkColor,
                                textDecoration = TextDecoration.Underline,
                                fontWeight = FontWeight.Medium
                            )
                        ) {
                            append(span.label)
                        }
                        addStringAnnotation("URL", span.url, start, length)
                    }
                }
            }
        }
    }

    ClickableText(
        text = annotated,
        style = style,
        modifier = modifier,
        onClick = { offset ->
            annotated.getStringAnnotations("URL", offset, offset)
                .firstOrNull()
                ?.let { onLinkClick(it.item) }
        }
    )
}
