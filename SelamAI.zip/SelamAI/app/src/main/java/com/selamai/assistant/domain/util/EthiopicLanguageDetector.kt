package com.selamai.assistant.domain.util

/**
 * Detects whether a text string contains Ethiopic script characters (U+1200..U+137F)
 * to select am-ET vs en-US for TextToSpeech read-aloud.
 */
object EthiopicLanguageDetector {

    const val LOCALE_AMHARIC = "am-ET"
    const val LOCALE_ENGLISH = "en-US"

    private const val ETHIOPIC_START = 'ሀ'
    private const val ETHIOPIC_END = '፿'

    fun containsEthiopic(text: String): Boolean {
        return text.any { ch -> ch in ETHIOPIC_START..ETHIOPIC_END }
    }

    fun detectTtsLocaleTag(text: String): String {
        return if (containsEthiopic(text)) LOCALE_AMHARIC else LOCALE_ENGLISH
    }
}
