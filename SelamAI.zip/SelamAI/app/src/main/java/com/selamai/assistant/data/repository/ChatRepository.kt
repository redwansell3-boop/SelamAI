package com.selamai.assistant.data.repository

import com.selamai.assistant.data.local.AttachmentManager
import com.selamai.assistant.data.local.ConversationDao
import com.selamai.assistant.data.local.ConversationEntity
import com.selamai.assistant.data.local.MessageDao
import com.selamai.assistant.data.local.MessageEntity
import com.selamai.assistant.domain.model.AttachmentType
import com.selamai.assistant.domain.model.Conversation
import com.selamai.assistant.domain.model.GroundingSource
import com.selamai.assistant.domain.model.Message
import com.selamai.assistant.domain.model.MessageErrorType
import com.selamai.assistant.domain.model.MessageRole
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ChatRepository @Inject constructor(
    private val conversationDao: ConversationDao,
    private val messageDao: MessageDao,
    private val attachmentManager: AttachmentManager,
    private val json: Json
) {
    fun observeConversations(searchQuery: String): Flow<List<Conversation>> {
        val source = if (searchQuery.isBlank()) {
            conversationDao.observeAll()
        } else {
            conversationDao.search(searchQuery.trim())
        }
        return source.map { list -> list.map { it.toDomain() } }
    }

    fun observeConversation(id: Long): Flow<Conversation?> =
        conversationDao.observeById(id).map { it?.toDomain() }

    suspend fun getConversation(id: Long): Conversation? =
        conversationDao.getById(id)?.toDomain()

    fun observeMessages(conversationId: Long): Flow<List<Message>> =
        messageDao.observeForConversation(conversationId).map { list ->
            list.map { it.toDomain() }
        }

    suspend fun getMessagesOnce(conversationId: Long): List<Message> =
        messageDao.getForConversationOnce(conversationId).map { it.toDomain() }

    suspend fun createConversation(title: String = "New chat"): Long {
        val now = System.currentTimeMillis()
        return conversationDao.insert(
            ConversationEntity(
                title = title,
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun renameConversation(id: Long, newTitle: String) {
        val cleaned = newTitle.trim()
        if (cleaned.isNotEmpty()) {
            conversationDao.updateTitle(id, cleaned)
        }
    }

    suspend fun togglePin(id: Long, currentlyPinned: Boolean) {
        conversationDao.updatePinned(id, !currentlyPinned)
    }

    suspend fun updatePersona(id: Long, customSystemPrompt: String?) {
        val cleaned = customSystemPrompt?.trim()?.takeIf { it.isNotEmpty() }
        conversationDao.updatePersona(id, cleaned)
    }

    /**
     * Cascade-deletes conversation, messages (via Room FK), and associated local attachment files.
     */
    suspend fun deleteConversation(id: Long) {
        val paths = messageDao.getAttachmentPathsForConversation(id)
        conversationDao.deleteById(id)
        attachmentManager.deleteFiles(paths)
    }

    suspend fun addMessage(message: Message): Long {
        val id = messageDao.insert(message.toEntity())
        conversationDao.touch(message.conversationId)
        return id
    }

    suspend fun updateMessage(message: Message) {
        messageDao.update(message.toEntity())
        conversationDao.touch(message.conversationId)
    }

    suspend fun deleteMessage(id: Long) {
        messageDao.deleteById(id)
    }

    suspend fun deleteMessagesFrom(conversationId: Long, fromId: Long) {
        messageDao.deleteFromId(conversationId, fromId)
    }

    fun generateAutoTitle(firstUserMessage: String): String {
        val cleaned = firstUserMessage.trim().replace(Regex("\s+"), " ")
        return when {
            cleaned.isEmpty() -> "New chat"
            cleaned.length <= 42 -> cleaned
            else -> cleaned.take(42).substringBeforeLast(" ", cleaned.take(42)) + "…"
        }
    }

    private fun ConversationEntity.toDomain() = Conversation(
        id = id,
        title = title,
        isPinned = isPinned,
        customSystemPrompt = customSystemPrompt,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    private fun MessageEntity.toDomain(): Message {
        val sources = groundingSourcesJson?.let { raw ->
            runCatching { json.decodeFromString<List<GroundingSource>>(raw) }.getOrDefault(emptyList())
        } ?: emptyList()

        return Message(
            id = id,
            conversationId = conversationId,
            role = runCatching { MessageRole.valueOf(role) }.getOrDefault(MessageRole.ASSISTANT),
            content = content,
            modelUsed = modelUsed,
            attachmentPath = attachmentPath,
            attachmentMimeType = attachmentMimeType,
            attachmentName = attachmentName,
            attachmentType = attachmentType?.let { runCatching { AttachmentType.valueOf(it) }.getOrNull() },
            groundingSources = sources,
            errorType = runCatching { MessageErrorType.valueOf(errorType) }.getOrDefault(MessageErrorType.NONE),
            errorDetail = errorDetail,
            isPartial = isPartial,
            createdAt = createdAt
        )
    }

    private fun Message.toEntity() = MessageEntity(
        id = id,
        conversationId = conversationId,
        role = role.name,
        content = content,
        modelUsed = modelUsed,
        attachmentPath = attachmentPath,
        attachmentMimeType = attachmentMimeType,
        attachmentName = attachmentName,
        attachmentType = attachmentType?.name,
        groundingSourcesJson = if (groundingSources.isEmpty()) null else json.encodeToString(groundingSources),
        errorType = errorType.name,
        errorDetail = errorDetail,
        isPartial = isPartial,
        createdAt = createdAt
    )
}
