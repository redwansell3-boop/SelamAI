package com.selamai.assistant.domain.phase2

import com.selamai.assistant.domain.util.EthiopianDate
import kotlinx.coroutines.flow.Flow

/**
 * Phase 2 Seam 1: Real-time voice conversation mode via Gemini Live API.
 * Uses `gemini-3.8-live` (note: `gemini-3.5-flash-lite` does NOT support the Live API).
 */
interface LiveVoiceSessionClient {
    companion object {
        const val LIVE_API_MODEL = "gemini-3.8-live"
    }

    sealed class LiveEvent {
        data object Connected : LiveEvent()
        data class AudioChunk(val pcm16Bytes: ByteArray) : LiveEvent()
        data class TranscriptDelta(val text: String, val isUser: Boolean) : LiveEvent()
        data class Error(val message: String) : LiveEvent()
        data object Closed : LiveEvent()
    }

    fun startSession(apiKey: String, systemInstruction: String): Flow<LiveEvent>
    suspend fun sendAudioFrame(pcm16Bytes: ByteArray)
    suspend fun closeSession()
}

/**
 * Phase 2 Seam 2: Latin-to-Ethiopic phonetic transliteration input (e.g. "selam" -> "ሰላም").
 */
interface EthiopicTransliterator {
    fun transliterate(latinInput: String): String
    fun suggestions(latinToken: String, limit: Int = 5): List<String>
}

/**
 * Phase 2 Seam 3: Ethiopian public & religious holidays and personal reminders.
 */
data class EthiopianHoliday(
    val nameEnglish: String,
    val nameAmharic: String,
    val ethiopianDate: EthiopianDate,
    val isMovable: Boolean
)

interface EthiopianHolidayProvider {
    fun holidaysForYear(ethiopianYear: Int): List<EthiopianHoliday>
    fun upcomingHolidays(fromDate: EthiopianDate, count: Int = 3): List<EthiopianHoliday>
}

/**
 * Phase 2 Seam 4: Home-screen quick-ask AppWidget bridge.
 */
interface QuickAskWidgetBridge {
    fun submitQuickPrompt(prompt: String)
    fun refreshWidgetState()
}
