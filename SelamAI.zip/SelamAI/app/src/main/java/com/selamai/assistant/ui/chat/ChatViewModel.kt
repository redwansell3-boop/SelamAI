package com.selamai.assistant.ui.chat

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.selamai.assistant.data.local.AttachmentManager
import com.selamai.assistant.data.local.AttachmentTooLargeException
import com.selamai.assistant.data.local.EncryptedApiKeyStore
import com.selamai.assistant.data.local.ExportBackupManager
import com.selamai.assistant.data.local.SavedAttachment
import com.selamai.assistant.data.local.SettingsRepository
import com.selamai.assistant.data.remote.GeminiApiClient
import com.selamai.assistant.data.remote.GeminiContent
import com.selamai.assistant.data.remote.GeminiInlineData
import com.selamai.assistant.data.remote.GeminiPart
import com.selamai.assistant.data.remote.GeminiStreamEvent
import com.selamai.assistant.data.repository.ChatRepository
import com.selamai.assistant.data.repository.MemoryRepository
import com.selamai.assistant.domain.model.Conversation
import com.selamai.assistant.domain.model.GroundingSource
import com.selamai.assistant.domain.model.Message
import com.selamai.assistant.domain.model.MessageErrorType
import com.selamai.assistant.domain.model.MessageRole
import com.selamai.assistant.domain.model.PendingShare
import com.selamai.assistant.domain.util.ParsedMemoryCandidate
import com.selamai.assistant.domain.util.StreamingMemoryParser
import com.selamai.assistant.domain.util.SystemPromptBuilder
import com.selamai.assistant.domain.util.TokenBudgetWindow
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class ChatUiEvent {
    data class ShowMessage(val message: String) : ChatUiEvent()
    data class PromptSaveMemory(val candidate: ParsedMemoryCandidate) : ChatUiEvent()
    data class ShareExportUri(val uri: Uri, val mimeType: String) : ChatUiEvent()
    data object PdfTooLarge : ChatUiEvent()
}

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class ChatViewModel @Inject constructor(
    private val chatRepository: ChatRepository,
    private val memoryRepository: MemoryRepository,
    private val settingsRepository: SettingsRepository,
    private val apiKeyStore: EncryptedApiKeyStore,
    private val geminiApiClient: GeminiApiClient,
    private val attachmentManager: AttachmentManager,
    private val exportBackupManager: ExportBackupManager
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val conversations: StateFlow<List<Conversation>> = _searchQuery
        .flatMapLatest { query -> chatRepository.observeConversations(query) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _activeConversationId = MutableStateFlow<Long?>(null)
    val activeConversationId: StateFlow<Long?> = _activeConversationId.asStateFlow()

    val activeConversation: StateFlow<Conversation?> = _activeConversationId
        .flatMapLatest { id -> if (id == null) flowOf(null) else chatRepository.observeConversation(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val messages: StateFlow<List<Message>> = _activeConversationId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else chatRepository.observeMessages(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _pendingAttachment = MutableStateFlow<SavedAttachment?>(null)
    val pendingAttachment: StateFlow<SavedAttachment?> = _pendingAttachment.asStateFlow()

    private val _isStreaming = MutableStateFlow(false)
    val isStreaming: StateFlow<Boolean> = _isStreaming.asStateFlow()

    private val _editingMessageId = MutableStateFlow<Long?>(null)
    val editingMessageId: StateFlow<Long?> = _editingMessageId.asStateFlow()

    private val _events = MutableSharedFlow<ChatUiEvent>()
    val events: SharedFlow<ChatUiEvent> = _events.asSharedFlow()

    private var streamingJob: Job? = null

    init {
        viewModelScope.launch {
            val existing = chatRepository.observeConversations("").stateIn(viewModelScope).value
            if (existing.isNotEmpty() && _activeConversationId.value == null) {
                _activeConversationId.value = existing.first().id
            }
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateInputText(text: String) {
        _inputText.value = text
    }

    fun appendVoiceTranscript(transcript: String) {
        val current = _inputText.value
        _inputText.value = if (current.isBlank()) transcript else "$current $transcript"
    }

    fun selectConversation(id: Long) {
        stopStreaming()
        _editingMessageId.value = null
        _activeConversationId.value = id
    }

    fun startNewChat() {
        stopStreaming()
        _editingMessageId.value = null
        _pendingAttachment.value = null
        _inputText.value = ""
        viewModelScope.launch {
            val newId = chatRepository.createConversation("New chat")
            _activeConversationId.value = newId
        }
    }

    fun renameConversation(id: Long, newTitle: String) {
        viewModelScope.launch { chatRepository.renameConversation(id, newTitle) }
    }

    fun togglePin(conversation: Conversation) {
        viewModelScope.launch { chatRepository.togglePin(conversation.id, conversation.isPinned) }
    }

    fun updatePersona(customPrompt: String?) {
        val convId = _activeConversationId.value ?: return
        viewModelScope.launch { chatRepository.updatePersona(convId, customPrompt) }
    }

    fun deleteConversation(id: Long) {
        if (_activeConversationId.value == id) {
            stopStreaming()
            _activeConversationId.value = null
        }
        viewModelScope.launch {
            chatRepository.deleteConversation(id)
        }
    }

    fun createCameraUri(): Uri = attachmentManager.createCameraCaptureUri()

    fun attachImage(uri: Uri) {
        viewModelScope.launch {
            runCatching { attachmentManager.processAndSaveImage(uri) }
                .onSuccess { _pendingAttachment.value = it }
                .onFailure { _events.emit(ChatUiEvent.ShowMessage(it.message ?: "Failed to load image")) }
        }
    }

    fun attachPdf(uri: Uri) {
        viewModelScope.launch {
            try {
                _pendingAttachment.value = attachmentManager.processAndSavePdf(uri)
            } catch (_: AttachmentTooLargeException) {
                _events.emit(ChatUiEvent.PdfTooLarge)
            } catch (e: Exception) {
                _events.emit(ChatUiEvent.ShowMessage(e.message ?: "Failed to attach PDF"))
            }
        }
    }

    fun clearPendingAttachment() {
        _pendingAttachment.value?.let { attachmentManager.deleteFiles(listOf(it.localPath)) }
        _pendingAttachment.value = null
    }

    fun handleIncomingShare(share: PendingShare) {
        viewModelScope.launch {
            if (_activeConversationId.value == null) {
                _activeConversationId.value = chatRepository.createConversation("New chat")
            }
            if (!share.text.isNullOrBlank()) {
                _inputText.value = share.text
            }
            if (!share.imageUriString.isNullOrBlank()) {
                attachImage(Uri.parse(share.imageUriString))
            }
        }
    }

    fun beginEditLastUserMessage(message: Message) {
        if (message.role != MessageRole.USER || _isStreaming.value) return
        _editingMessageId.value = message.id
        _inputText.value = message.content
    }

    fun cancelEdit() {
        _editingMessageId.value = null
        _inputText.value = ""
    }

    fun sendMessage() {
        val text = _inputText.value.trim()
        val attachment = _pendingAttachment.value
        if (text.isEmpty() && attachment == null) return
        if (_isStreaming.value) return

        viewModelScope.launch {
            val convId = _activeConversationId.value ?: chatRepository.createConversation("New chat").also {
                _activeConversationId.value = it
            }

            val editId = _editingMessageId.value
            if (editId != null) {
                // Edit-and-resend: remove edited user message and everything after it
                chatRepository.deleteMessagesFrom(convId, editId)
                _editingMessageId.value = null
            }

            val existingMessages = chatRepository.getMessagesOnce(convId)
            val userMsg = Message(
                conversationId = convId,
                role = MessageRole.USER,
                content = text,
                attachmentPath = attachment?.localPath,
                attachmentMimeType = attachment?.mimeType,
                attachmentName = attachment?.displayName,
                attachmentType = attachment?.type
            )
            chatRepository.addMessage(userMsg)

            // Auto-title from the first user message
            if (existingMessages.isEmpty()) {
                val titleSeed = text.ifBlank { attachment?.displayName ?: "New chat" }
                chatRepository.renameConversation(convId, chatRepository.generateAutoTitle(titleSeed))
            }

            _inputText.value = ""
            _pendingAttachment.value = null

            streamAssistantReply(convId)
        }
    }

    /**
     * Regenerates the last reply by deleting the trailing assistant message first
     * so the last item in Gemini `contents` is always a user turn.
     */
    fun regenerateLastReply() {
        val convId = _activeConversationId.value ?: return
        if (_isStreaming.value) return
        viewModelScope.launch {
            val history = chatRepository.getMessagesOnce(convId)
            val last = history.lastOrNull() ?: return@launch
            if (last.role == MessageRole.ASSISTANT) {
                chatRepository.deleteMessage(last.id)
            }
            streamAssistantReply(convId)
        }
    }

    fun retryMessage(errorOrPartialMessage: Message) {
        val convId = errorOrPartialMessage.conversationId
        if (_isStreaming.value) return
        viewModelScope.launch {
            if (errorOrPartialMessage.role == MessageRole.ASSISTANT) {
                chatRepository.deleteMessage(errorOrPartialMessage.id)
            }
            streamAssistantReply(convId)
        }
    }

    fun stopStreaming() {
        streamingJob?.cancel()
        streamingJob = null
        _isStreaming.value = false
    }

    fun saveMemoryCandidate(candidate: ParsedMemoryCandidate) {
        viewModelScope.launch {
            memoryRepository.addIfUnique(candidate.category, candidate.fact)
        }
    }

    fun exportActiveConversation(asMarkdown: Boolean) {
        val conv = activeConversation.value ?: return
        viewModelScope.launch {
            val msgs = chatRepository.getMessagesOnce(conv.id)
            runCatching { exportBackupManager.createExportFileUri(conv, msgs, asMarkdown) }
                .onSuccess { uri ->
                    val mime = if (asMarkdown) "text/markdown" else "text/plain"
                    _events.emit(ChatUiEvent.ShareExportUri(uri, mime))
                }
                .onFailure { _events.emit(ChatUiEvent.ShowMessage(it.message ?: "Export failed")) }
        }
    }

    private fun streamAssistantReply(conversationId: Long) {
        streamingJob?.cancel()
        streamingJob = viewModelScope.launch {
            _isStreaming.value = true
            var assistantMsg = Message(
                conversationId = conversationId,
                role = MessageRole.ASSISTANT,
                content = ""
            )
            var assistantId = 0L

            try {
                val apiKey = apiKeyStore.getApiKey()
                if (apiKey.isNullOrBlank()) {
                    chatRepository.addMessage(
                        assistantMsg.copy(errorType = MessageErrorType.MISSING_API_KEY)
                    )
                    return@launch
                }

                val settings = settingsRepository.getSettingsOnce()
                val conversation = chatRepository.getConversation(conversationId)
                val allMessages = chatRepository.getMessagesOnce(conversationId)
                val memories = memoryRepository.getAllOnce()

                val windowed = TokenBudgetWindow.selectWindow(allMessages)
                if (windowed.messages.isEmpty()) return@launch

                val contents = windowed.messages.map { msg ->
                    val parts = mutableListOf<GeminiPart>()
                    if (!msg.attachmentPath.isNullOrBlank() && !msg.attachmentMimeType.isNullOrBlank()) {
                        val b64 = attachmentManager.readAsBase64(msg.attachmentPath)
                        if (b64 != null) {
                            parts.add(
                                GeminiPart(
                                    inlineData = GeminiInlineData(
                                        mimeType = msg.attachmentMimeType,
                                        data = b64
                                    )
                                )
                            )
                        }
                    }
                    if (msg.content.isNotBlank()) {
                        parts.add(GeminiPart(text = msg.content))
                    } else if (parts.isEmpty()) {
                        parts.add(GeminiPart(text = " "))
                    }
                    GeminiContent(
                        role = if (msg.role == MessageRole.USER) "user" else "model",
                        parts = parts
                    )
                }

                val systemInstruction = SystemPromptBuilder.buildSystemInstruction(
                    baseSystemPrompt = settings.defaultSystemPrompt,
                    personaOverride = conversation?.customSystemPrompt,
                    memoryFacts = memories,
                    droppedHistorySummary = windowed.droppedSummary
                )

                assistantId = chatRepository.addMessage(assistantMsg)
                assistantMsg = assistantMsg.copy(id = assistantId)

                val memoryParser = StreamingMemoryParser()
                val visibleText = StringBuilder()
                val extractedMemories = mutableListOf<ParsedMemoryCandidate>()
                var sources: List<GroundingSource> = emptyList()
                var modelUsed: String? = null

                geminiApiClient.streamGenerateContent(
                    apiKey = apiKey,
                    selectedModel = settings.defaultModel,
                    fallbackModels = settings.fallbackModels,
                    systemInstruction = systemInstruction,
                    contents = contents,
                    enableGoogleSearch = settings.liveWebSearchEnabled
                ).collect { event ->
                    when (event) {
                        is GeminiStreamEvent.ModelSelected -> {
                            modelUsed = event.model
                            assistantMsg = assistantMsg.copy(modelUsed = modelUsed)
                            chatRepository.updateMessage(assistantMsg)
                        }
                        is GeminiStreamEvent.TextDelta -> {
                            val parsed = memoryParser.feed(event.text)
                            if (parsed.visibleTextDelta.isNotEmpty()) {
                                visibleText.append(parsed.visibleTextDelta)
                                assistantMsg = assistantMsg.copy(content = visibleText.toString())
                                chatRepository.updateMessage(assistantMsg)
                            }
                            extractedMemories.addAll(parsed.extractedMemories)
                        }
                        is GeminiStreamEvent.GroundingSources -> {
                            sources = event.sources
                            assistantMsg = assistantMsg.copy(groundingSources = sources)
                            chatRepository.updateMessage(assistantMsg)
                        }
                        is GeminiStreamEvent.Completed -> {
                            val flushed = memoryParser.flush()
                            if (flushed.visibleTextDelta.isNotEmpty()) {
                                visibleText.append(flushed.visibleTextDelta)
                            }
                            extractedMemories.addAll(flushed.extractedMemories)
                            assistantMsg = assistantMsg.copy(
                                content = visibleText.toString().trimEnd(),
                                modelUsed = event.model,
                                groundingSources = sources,
                                errorType = MessageErrorType.NONE,
                                isPartial = false
                            )
                            chatRepository.updateMessage(assistantMsg)
                            handleExtractedMemories(extractedMemories, settings.askBeforeSavingMemory)
                        }
                        is GeminiStreamEvent.Failed -> {
                            val flushed = memoryParser.flush()
                            if (flushed.visibleTextDelta.isNotEmpty()) {
                                visibleText.append(flushed.visibleTextDelta)
                            }
                            val hasPartial = visibleText.isNotEmpty()
                            assistantMsg = assistantMsg.copy(
                                content = visibleText.toString().trimEnd(),
                                modelUsed = event.model ?: modelUsed,
                                groundingSources = sources,
                                errorType = event.errorType,
                                errorDetail = event.detail,
                                isPartial = hasPartial
                            )
                            chatRepository.updateMessage(assistantMsg)
                        }
                    }
                }
            } catch (_: CancellationException) {
                // User tapped Stop: preserve partial text cleanly
                if (assistantId != 0L) {
                    if (assistantMsg.content.isBlank()) {
                        chatRepository.deleteMessage(assistantId)
                    } else {
                        chatRepository.updateMessage(assistantMsg.copy(isPartial = true))
                    }
                }
            } finally {
                _isStreaming.value = false
            }
        }
    }

    private suspend fun handleExtractedMemories(
        candidates: List<ParsedMemoryCandidate>,
        askBeforeSaving: Boolean
    ) {
        for (candidate in candidates) {
            if (memoryRepository.isDuplicate(candidate.fact)) continue
            if (askBeforeSaving) {
                _events.emit(ChatUiEvent.PromptSaveMemory(candidate))
            } else {
                memoryRepository.addIfUnique(candidate.category, candidate.fact)
            }
        }
    }
}
