package com.selamai.assistant

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.selamai.assistant.data.local.SettingsRepository
import com.selamai.assistant.domain.model.AppSettings
import com.selamai.assistant.domain.model.PendingShare
import com.selamai.assistant.ui.chat.ChatScreen
import com.selamai.assistant.ui.chat.ChatViewModel
import com.selamai.assistant.ui.memory.MemoryScreen
import com.selamai.assistant.ui.memory.MemoryViewModel
import com.selamai.assistant.ui.settings.SettingsScreen
import com.selamai.assistant.ui.settings.SettingsViewModel
import com.selamai.assistant.ui.theme.SelamAITheme
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.MutableStateFlow
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    @Inject
    lateinit var settingsRepository: SettingsRepository

    private val incomingShareFlow = MutableStateFlow<PendingShare?>(null)
    private var isUnlocked by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        parseShareIntent(intent)

        setContent {
            val settings by settingsRepository.settingsFlow.collectAsState(initial = AppSettings())
            val pendingShare by incomingShareFlow.collectAsState()

            SelamAITheme(
                themeMode = settings.themeMode,
                dynamicColor = settings.dynamicColorEnabled
            ) {
                if (settings.biometricLockEnabled && !isUnlocked) {
                    LaunchedEffect(Unit) { promptBiometricUnlock() }
                    BiometricLockScreen(onUnlockClick = { promptBiometricUnlock() })
                } else {
                    SelamNavGraph(
                        pendingShare = pendingShare,
                        onShareConsumed = { incomingShareFlow.value = null }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        parseShareIntent(intent)
    }

    private fun parseShareIntent(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        val mime = intent.type ?: return
        when {
            mime.startsWith("text/") -> {
                val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
                if (!sharedText.isNullOrBlank()) {
                    incomingShareFlow.value = PendingShare(text = sharedText)
                }
            }
            mime.startsWith("image/") -> {
                val uri: Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(Intent.EXTRA_STREAM)
                }
                if (uri != null) {
                    incomingShareFlow.value = PendingShare(imageUriString = uri.toString())
                }
            }
        }
    }

    private fun promptBiometricUnlock() {
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.BIOMETRIC_WEAK or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL

        val canAuth = BiometricManager.from(this).canAuthenticate(authenticators)
        if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) {
            isUnlocked = true
            return
        }

        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    isUnlocked = true
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.unlock_title))
            .setSubtitle(getString(R.string.unlock_subtitle))
            .setAllowedAuthenticators(authenticators)
            .build()
        prompt.authenticate(info)
    }
}

@Composable
private fun SelamNavGraph(
    pendingShare: PendingShare?,
    onShareConsumed: () -> Unit
) {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "chat") {
        composable("chat") {
            val chatViewModel: ChatViewModel = hiltViewModel()
            LaunchedEffect(pendingShare) {
                if (pendingShare != null) {
                    chatViewModel.handleIncomingShare(pendingShare)
                    onShareConsumed()
                }
            }
            ChatScreen(
                viewModel = chatViewModel,
                onNavigateMemory = { navController.navigate("memory") },
                onNavigateSettings = { navController.navigate("settings") }
            )
        }
        composable("memory") {
            val memoryViewModel: MemoryViewModel = hiltViewModel()
            MemoryScreen(
                viewModel = memoryViewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable("settings") {
            val settingsViewModel: SettingsViewModel = hiltViewModel()
            SettingsScreen(
                viewModel = settingsViewModel,
                onBack = { navController.popBackStack() }
            )
        }
    }
}

@Composable
private fun BiometricLockScreen(onUnlockClick: () -> Unit) {
    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(16.dp))
            Text(stringResource(R.string.unlock_title), style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(8.dp))
            Text(
                stringResource(R.string.unlock_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(24.dp))
            Button(onClick = onUnlockClick) {
                Text(stringResource(R.string.unlock_button))
            }
        }
    }
}
