package com.selamai.assistant.domain.util

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

data class EthiopianDate(
    val year: Int,
    val month: Int,
    val day: Int
) {
    val monthNameEnglish: String
        get() = ENGLISH_MONTHS.getOrElse(month - 1) { "Month $month" }

    val monthNameAmharic: String
        get() = AMHARIC_MONTHS.getOrElse(month - 1) { "ወር $month" }

    fun formatEnglish(): String = "$monthNameEnglish $day, $year E.C."

    fun formatAmharic(): String = "$monthNameAmharic $day ቀን $year ዓ.ም."

    companion object {
        val ENGLISH_MONTHS = listOf(
            "Meskerem", "Tikimt", "Hidar", "Tahsas",
            "Tir", "Yekatit", "Megabit", "Miazia",
            "Ginbot", "Sene", "Hamle", "Nehase",
            "Pagume"
        )

        val AMHARIC_MONTHS = listOf(
            "መስከረም", "ጥቅምት", "ኅዳር", "ታኅሣሥ",
            "ጥር", "የካቲት", "መጋቢት", "ሚያዝያ",
            "ግንቦት", "ሰኔ", "ሐምሌ", "ነሐሴ",
            "ጳጉሜን"
        )
    }
}

/**
 * Pure Kotlin Gregorian <-> Ethiopian Calendar converter using Julian Day Numbers (JDN).
 * Epoch of the Ethiopian calendar (Meskerem 1, 1 E.C.) is JDN 1724221 (August 29, 8 CE Julian).
 * An Ethiopian year Y is a leap year (Pagume has 6 days) when (Y + 1) % 4 == 0, i.e., Y % 4 == 3.
 */
object EthiopianCalendarConverter {

    // JDN of Meskerem 1, Year 0 E.C. so that 4-year leap cycles align Pagume 6 with year % 4 == 3
    private const val ETHIOPIC_EPOCH_JDN = 1723856L

    fun isEthiopianLeapYear(ethiopianYear: Int): Boolean {
        return Math.floorMod(ethiopianYear, 4) == 3
    }

    fun gregorianToJdn(year: Int, month: Int, day: Int): Long {
        val a = (14 - month) / 12
        val y = year + 4800 - a
        val m = month + 12 * a - 3
        return day.toLong() +
            (153L * m + 2L) / 5L +
            365L * y +
            y / 4L -
            y / 100L +
            y / 400L -
            32045L
    }

    fun fromGregorian(date: LocalDate): EthiopianDate {
        return fromGregorian(date.year, date.monthValue, date.dayOfMonth)
    }

    fun fromGregorian(year: Int, month: Int, day: Int): EthiopianDate {
        val jdn = gregorianToJdn(year, month, day)
        val r = Math.floorMod(jdn - ETHIOPIC_EPOCH_JDN, 1461L)
        val n = Math.floorMod(r, 365L) + 365L * (r / 1460L)
        val ethYear = (4L * Math.floorDiv(jdn - ETHIOPIC_EPOCH_JDN, 1461L) +
            r / 365L - r / 1460L).toInt()
        val ethMonth = (n / 30L + 1L).toInt()
        val ethDay = (n % 30L + 1L).toInt()
        return EthiopianDate(year = ethYear, month = ethMonth, day = ethDay)
    }

    fun amharicDayOfWeek(dayOfWeek: DayOfWeek): String = when (dayOfWeek) {
        DayOfWeek.MONDAY -> "ሰኞ"
        DayOfWeek.TUESDAY -> "ማክሰኞ"
        DayOfWeek.WEDNESDAY -> "ረቡዕ"
        DayOfWeek.THURSDAY -> "ሐሙስ"
        DayOfWeek.FRIDAY -> "ዓርብ"
        DayOfWeek.SATURDAY -> "ቅዳሜ"
        DayOfWeek.SUNDAY -> "እሑድ"
    }

    fun buildClockBlock(now: ZonedDateTime = ZonedDateTime.now()): String {
        val ethDate = fromGregorian(now.toLocalDate())
        val isoDate = now.toLocalDate().format(DateTimeFormatter.ISO_LOCAL_DATE)
        val weekdayEn = now.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, Locale.ENGLISH)
        val weekdayAm = amharicDayOfWeek(now.dayOfWeek)
        val timeStr = now.format(DateTimeFormatter.ofPattern("HH:mm:ss", Locale.ENGLISH))
        val tzId = now.zone.id
        val offset = now.offset.id
        return buildString {
            appendLine("<current_time>")
            appendLine("Gregorian Date: $weekdayEn, $isoDate")
            appendLine("Local Time: $timeStr ($tzId, UTC$offset)")
            appendLine("Ethiopian Date (EN): ${ethDate.formatEnglish()}")
            appendLine("Ethiopian Date (AM): $weekdayAm፣ ${ethDate.formatAmharic()}")
            appendLine("Use these exact pre-computed dates when answering date/time questions. Do not convert Gregorian/Ethiopian dates yourself.")
            append("</current_time>")
        }
    }
}
