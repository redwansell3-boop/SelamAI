package com.selamai.assistant.ui.chat

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.selamai.assistant.R
import com.selamai.assistant.domain.model.AttachmentType
import com.selamai.assistant.domain.model.Conversation
import com.selamai.assistant.domain.model.Message
import com.selamai.assistant.domain.model.MessageErrorType
import com.selamai.assistant.domain.model.MessageRole
import com.selamai.assistant.domain.util.EthiopicLanguageDetector
import com.selamai.assistant.ui.components.MarkdownText
import com.selamai.assistant.ui.voice.VoiceController
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    onNavigateMemory: () -> Unit,
    onNavigateSettings: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val snackbarHostState = remember { SnackbarHostState() }
    val listState = rememberLazyListState()

    val conversations by viewModel.conversations.collectAsState()
    val activeConvId by viewModel.activeConversationId.collectAsState()
    val activeConversation by viewModel.activeConversation.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val inputText by viewModel.inputText.collectAsState()
    val pendingAttachment by viewModel.pendingAttachment.collectAsState()
    val isStreaming by viewModel.isStreaming.collectAsState()
    val editingMessageId by viewModel.editingMessageId.collectAsState()

    val voiceController = remember { VoiceController(context) }
    val isListening by voiceController.isListening.collectAsState()
    val speakingMessageId by voiceController.speakingMessageId.collectAsState()
    var voiceLocale by remember { mutableStateOf(EthiopicLanguageDetector.LOCALE_AMHARIC) }
    var showTtsInstallDialog by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        onDispose { voiceController.release() }
    }

    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }
    var showAttachMenu by remember { mutableStateOf(false) }
    var showTopOverflow by remember { mutableStateOf(false) }
    var showPersonaDialog by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<Conversation?>(null) }
    var deleteTarget by remember { mutableStateOf<Conversation?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) viewModel.attachImage(uri) }

    val cameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        val uri = pendingCameraUri
        if (success && uri != null) viewModel.attachImage(uri)
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val uri = viewModel.createCameraUri()
            pendingCameraUri = uri
            cameraLauncher.launch(uri)
        } else {
            Toast.makeText(context, context.getString(R.string.camera_permission_needed), Toast.LENGTH_LONG).show()
        }
    }

    val pdfPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) viewModel.attachPdf(uri) }

    val startVoiceInput: () -> Unit = {
        voiceController.startListening(
            localeTag = voiceLocale,
            onResult = { transcript -> viewModel.appendVoiceTranscript(transcript) },
            onError = { isAmharicUnavailable, _ ->
                val msg = if (isAmharicUnavailable) {
                    context.getString(R.string.speech_unavailable_am)
                } else {
                    context.getString(R.string.speech_unavailable)
                }
                scope.launch { snackbarHostState.showSnackbar(msg) }
            }
        )
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startVoiceInput()
        } else {
            Toast.makeText(context, context.getString(R.string.mic_permission_needed), Toast.LENGTH_LONG).show()
        }
    }

    LaunchedEffect(Unit) {
        viewModel.events.collect { event ->
            when (event) {
                is ChatUiEvent.ShowMessage -> snackbarHostState.showSnackbar(event.message)
                is ChatUiEvent.PdfTooLarge -> snackbarHostState.showSnackbar(
                    context.getString(R.string.pdf_too_large)
                )
                is ChatUiEvent.PromptSaveMemory -> {
                    val label = context.getString(R.string.memory_save_prompt, event.candidate.fact)
                    val res = snackbarHostState.showSnackbar(
                        message = label,
                        actionLabel = context.getString(R.string.save),
                        withDismissAction = true,
                        duration = SnackbarDuration.Long
                    )
                    if (res == SnackbarResult.ActionPerformed) {
                        viewModel.saveMemoryCandidate(event.candidate)
                    }
                }
                is ChatUiEvent.ShareExportUri -> {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = event.mimeType
                        putExtra(Intent.EXTRA_STREAM, event.uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(shareIntent, context.getString(R.string.app_name)))
                }
            }
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(modifier = Modifier.widthIn(max = 320.dp)) {
                Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.app_name),
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Button(onClick = {
                            viewModel.startNewChat()
                            scope.launch { drawerState.close() }
                        }) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.new_chat))
                        }
                    }

                    Spacer(Modifier.height(10.dp))

                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = viewModel::updateSearchQuery,
                        placeholder = { Text(stringResource(R.string.search_conversations)) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(Modifier.height(10.dp))

                    val pinned = conversations.filter { it.isPinned }
                    val recent = conversations.filterNot { it.isPinned }

                    LazyColumn(modifier = Modifier.weight(1f)) {
                        if (conversations.isEmpty()) {
                            item {
                                Text(
                                    text = stringResource(R.string.no_conversations),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }
                        if (pinned.isNotEmpty()) {
                            item {
                                Text(
                                    text = stringResource(R.string.pinned),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                            itemsIndexed(pinned, key = { _, c -> "pin_${c.id}" }) { _, conv ->
                                ConversationDrawerRow(
                                    conversation = conv,
                                    selected = conv.id == activeConvId,
                                    onSelect = {
                                        viewModel.selectConversation(conv.id)
                                        scope.launch { drawerState.close() }
                                    },
                                    onPin = { viewModel.togglePin(conv) },
                                    onRename = { renameTarget = conv },
                                    onDelete = { deleteTarget = conv }
                                )
                            }
                        }
                        if (recent.isNotEmpty()) {
                            item {
                                Text(
                                    text = stringResource(R.string.recent),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                            itemsIndexed(recent, key = { _, c -> "rec_${c.id}" }) { _, conv ->
                                ConversationDrawerRow(
                                    conversation = conv,
                                    selected = conv.id == activeConvId,
                                    onSelect = {
                                        viewModel.selectConversation(conv.id)
                                        scope.launch { drawerState.close() }
                                    },
                                    onPin = { viewModel.togglePin(conv) },
                                    onRename = { renameTarget = conv },
                                    onDelete = { deleteTarget = conv }
                                )
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    NavigationDrawerItem(
                        label = { Text(stringResource(R.string.memory)) },
                        icon = { Icon(Icons.Default.Psychology, contentDescription = null) },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            onNavigateMemory()
                        }
                    )
                    NavigationDrawerItem(
                        label = { Text(stringResource(R.string.settings)) },
                        icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            onNavigateSettings()
                        }
                    )
                }
            }
        }
    ) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = activeConversation?.title ?: stringResource(R.string.app_name),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (!activeConversation?.customSystemPrompt.isNullOrBlank()) {
                                Text(
                                    text = stringResource(R.string.persona),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menu")
                        }
                    },
                    actions = {
                        IconButton(onClick = { viewModel.startNewChat() }) {
                            Icon(Icons.Default.Add, contentDescription = stringResource(R.string.new_chat))
                        }
                        Box {
                            IconButton(onClick = { showTopOverflow = true }) {
                                Icon(Icons.Default.MoreVert, contentDescription = "More")
                            }
                            DropdownMenu(
                                expanded = showTopOverflow,
                                onDismissRequest = { showTopOverflow = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.persona)) },
                                    onClick = {
                                        showTopOverflow = false
                                        showPersonaDialog = true
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.export_txt)) },
                                    enabled = activeConversation != null && messages.isNotEmpty(),
                                    onClick = {
                                        showTopOverflow = false
                                        viewModel.exportActiveConversation(asMarkdown = false)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.export_md)) },
                                    enabled = activeConversation != null && messages.isNotEmpty(),
                                    onClick = {
                                        showTopOverflow = false
                                        viewModel.exportActiveConversation(asMarkdown = true)
                                    }
                                )
                            }
                        }
                    }
                )
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .imePadding()
            ) {
                val lastUserMsgId = messages.lastOrNull { it.role == MessageRole.USER }?.id
                val lastAssistantMsgId = messages.lastOrNull { it.role == MessageRole.ASSISTANT }?.id

                LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f).fillMaxWidth()
                ) {
                    itemsIndexed(messages, key = { _, m -> m.id }) { _, message ->
                        MessageBubble(
                            message = message,
                            isStreamingThis = isStreaming && message.id == lastAssistantMsgId,
                            canEdit = !isStreaming && message.id == lastUserMsgId,
                            canRegenerate = !isStreaming && message.id == lastAssistantMsgId,
                            isSpeaking = speakingMessageId == message.id,
                            onEdit = { viewModel.beginEditLastUserMessage(message) },
                            onRegenerate = { viewModel.regenerateLastReply() },
                            onRetry = { viewModel.retryMessage(message) },
                            onOpenSettings = onNavigateSettings,
                            onReadAloud = {
                                val ok = voiceController.speakMessage(message.id, message.content)
                                if (!ok) showTtsInstallDialog = true
                            }
                        )
                    }
                }

                // Edit indicator banner
                if (editingMessageId != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.secondaryContainer)
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.edit_and_resend),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        IconButton(onClick = viewModel::cancelEdit, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = stringResource(R.string.cancel))
                        }
                    }
                }

                // Pending attachment preview
                pendingAttachment?.let { att ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AssistChip(
                            onClick = {},
                            label = { Text(att.displayName, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            leadingIcon = {
                                Icon(
                                    imageVector = if (att.type == AttachmentType.PDF) Icons.Default.PictureAsPdf else Icons.Default.Image,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            trailingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Remove",
                                    modifier = Modifier.size(18.dp).clickable { viewModel.clearPendingAttachment() }
                                )
                            }
                        )
                    }
                }

                // Voice locale toggle chip + Composer
                Surface(tonalElevation = 2.dp) {
                    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(horizontal = 4.dp)
                        ) {
                            FilterChip(
                                selected = voiceLocale == EthiopicLanguageDetector.LOCALE_AMHARIC,
                                onClick = {
                                    voiceLocale = if (voiceLocale == EthiopicLanguageDetector.LOCALE_AMHARIC) {
                                        EthiopicLanguageDetector.LOCALE_ENGLISH
                                    } else {
                                        EthiopicLanguageDetector.LOCALE_AMHARIC
                                    }
                                },
                                label = {
                                    Text(if (voiceLocale == EthiopicLanguageDetector.LOCALE_AMHARIC) "Voice: am-ET" else "Voice: en-US")
                                }
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Box {
                                IconButton(onClick = { showAttachMenu = true }, enabled = !isStreaming) {
                                    Icon(Icons.Default.AttachFile, contentDescription = "Attach")
                                }
                                DropdownMenu(
                                    expanded = showAttachMenu,
                                    onDismissRequest = { showAttachMenu = false }
                                ) {
                                    DropdownMenuItem(
                                        text = { Text(stringResource(R.string.attach_photo)) },
                                        leadingIcon = { Icon(Icons.Default.Image, null) },
                                        onClick = {
                                            showAttachMenu = false
                                            photoPickerLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text(stringResource(R.string.attach_camera)) },
                                        leadingIcon = { Icon(Icons.Default.CameraAlt, null) },
                                        onClick = {
                                            showAttachMenu = false
                                            val hasPerm = ContextCompat.checkSelfPermission(
                                                context, Manifest.permission.CAMERA
                                            ) == PackageManager.PERMISSION_GRANTED
                                            if (hasPerm) {
                                                val uri = viewModel.createCameraUri()
                                                pendingCameraUri = uri
                                                cameraLauncher.launch(uri)
                                            } else {
                                                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                            }
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text(stringResource(R.string.attach_pdf)) },
                                        leadingIcon = { Icon(Icons.Default.PictureAsPdf, null) },
                                        onClick = {
                                            showAttachMenu = false
                                            pdfPickerLauncher.launch(arrayOf("application/pdf"))
                                        }
                                    )
                                }
                            }

                            OutlinedTextField(
                                value = inputText,
                                onValueChange = viewModel::updateInputText,
                                placeholder = { Text(stringResource(R.string.chat_placeholder)) },
                                maxLines = 5,
                                modifier = Modifier.weight(1f)
                            )

                            IconButton(
                                onClick = {
                                    if (isListening) {
                                        voiceController.stopListening()
                                    } else {
                                        val hasMic = ContextCompat.checkSelfPermission(
                                            context, Manifest.permission.RECORD_AUDIO
                                        ) == PackageManager.PERMISSION_GRANTED
                                        if (hasMic) startVoiceInput()
                                        else micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                },
                                enabled = !isStreaming
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "Voice input",
                                    tint = if (isListening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            if (isStreaming) {
                                IconButton(onClick = viewModel::stopStreaming) {
                                    Icon(
                                        imageVector = Icons.Default.Stop,
                                        contentDescription = stringResource(R.string.stop),
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            } else {
                                IconButton(
                                    onClick = viewModel::sendMessage,
                                    enabled = inputText.isNotBlank() || pendingAttachment != null
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.Send,
                                        contentDescription = stringResource(R.string.send),
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Rename Dialog
    renameTarget?.let { target ->
        var draft by remember(target.id) { mutableStateOf(target.title) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text(stringResource(R.string.rename_chat)) },
            text = {
                OutlinedTextField(value = draft, onValueChange = { draft = it }, singleLine = true)
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.renameConversation(target.id, draft)
                    renameTarget = null
                }) { Text(stringResource(R.string.save)) }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }

    // Delete Confirmation Dialog
    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text(stringResource(R.string.delete_chat)) },
            text = { Text(stringResource(R.string.delete_chat_confirm)) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteConversation(target.id)
                    deleteTarget = null
                }) { Text(stringResource(R.string.delete), color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }

    // Per-Conversation Persona Dialog
    if (showPersonaDialog) {
        var personaDraft by remember(activeConversation?.id) {
            mutableStateOf(activeConversation?.customSystemPrompt.orEmpty())
        }
        AlertDialog(
            onDismissRequest = { showPersonaDialog = false },
            title = { Text(stringResource(R.string.persona)) },
            text = {
                OutlinedTextField(
                    value = personaDraft,
                    onValueChange = { personaDraft = it },
                    placeholder = { Text(stringResource(R.string.persona_hint)) },
                    minLines = 3,
                    maxLines = 6
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.updatePersona(personaDraft)
                    showPersonaDialog = false
                }) { Text(stringResource(R.string.save)) }
            },
            dismissButton = {
                TextButton(onClick = { showPersonaDialog = false }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }

    // Missing Amharic TTS Voice Data Dialog
    if (showTtsInstallDialog) {
        AlertDialog(
            onDismissRequest = { showTtsInstallDialog = false },
            title = { Text(stringResource(R.string.read_aloud)) },
            text = { Text(stringResource(R.string.tts_missing_am)) },
            confirmButton = {
                TextButton(onClick = {
                    showTtsInstallDialog = false
                    runCatching { context.startActivity(voiceController.createInstallVoiceDataIntent()) }
                }) { Text(stringResource(R.string.install_voice_data)) }
            },
            dismissButton = {
                TextButton(onClick = { showTtsInstallDialog = false }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }
}

@Composable
private fun ConversationDrawerRow(
    conversation: Conversation,
    selected: Boolean,
    onSelect: () -> Unit,
    onPin: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    NavigationDrawerItem(
        label = {
            Text(
                text = conversation.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        },
        selected = selected,
        onClick = onSelect,
        badge = {
            Box {
                IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Options", modifier = Modifier.size(18.dp))
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = {
                            Text(
                                if (conversation.isPinned) stringResource(R.string.unpin_chat)
                                else stringResource(R.string.pin_chat)
                            )
                        },
                        leadingIcon = { Icon(Icons.Default.PushPin, null) },
                        onClick = {
                            menuOpen = false
                            onPin()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.rename_chat)) },
                        leadingIcon = { Icon(Icons.Default.Edit, null) },
                        onClick = {
                            menuOpen = false
                            onRename()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.delete_chat)) },
                        leadingIcon = { Icon(Icons.Default.Delete, null) },
                        onClick = {
                            menuOpen = false
                            onDelete()
                        }
                    )
                }
            }
        }
    )
}

@Composable
private fun MessageBubble(
    message: Message,
    isStreamingThis: Boolean,
    canEdit: Boolean,
    canRegenerate: Boolean,
    isSpeaking: Boolean,
    onEdit: () -> Unit,
    onRegenerate: () -> Unit,
    onRetry: () -> Unit,
    onOpenSettings: () -> Unit,
    onReadAloud: () -> Unit
) {
    val isUser = message.role == MessageRole.USER
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current

    val bubbleColor = when {
        message.errorType != MessageErrorType.NONE -> MaterialTheme.colorScheme.errorContainer
        isUser -> MaterialTheme.colorScheme.primaryContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    val textColor = when {
        message.errorType != MessageErrorType.NONE -> MaterialTheme.colorScheme.onErrorContainer
        isUser -> MaterialTheme.colorScheme.onPrimaryContainer
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Surface(
            color = bubbleColor,
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            modifier = Modifier.widthIn(max = 340.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // Attachment preview
                if (!message.attachmentPath.isNullOrBlank()) {
                    if (message.attachmentType == AttachmentType.IMAGE) {
                        AsyncImage(
                            model = File(message.attachmentPath),
                            contentDescription = message.attachmentName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp)
                                .clip(RoundedCornerShape(10.dp))
                        )
                    } else if (message.attachmentType == AttachmentType.PDF) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = textColor)
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = message.attachmentName ?: "document.pdf",
                                style = MaterialTheme.typography.labelMedium,
                                color = textColor
                            )
                        }
                    }
                }

                if (message.content.isNotBlank()) {
                    if (isUser) {
                        Text(
                            text = message.content,
                            style = MaterialTheme.typography.bodyLarge,
                            color = textColor
                        )
                    } else {
                        MarkdownText(markdown = message.content, textColor = textColor)
                    }
                }

                if (isStreamingThis) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("…", style = MaterialTheme.typography.bodySmall, color = textColor)
                    }
                }

                if (message.errorType != MessageErrorType.NONE) {
                    val errText = when (message.errorType) {
                        MessageErrorType.NO_NETWORK -> stringResource(R.string.error_no_network)
                        MessageErrorType.MISSING_API_KEY -> stringResource(R.string.error_missing_api_key)
                        MessageErrorType.INVALID_API_KEY -> stringResource(R.string.error_invalid_api_key)
                        MessageErrorType.RATE_LIMIT -> stringResource(R.string.error_rate_limit)
                        MessageErrorType.SAFETY_BLOCK -> stringResource(R.string.error_safety_block)
                        MessageErrorType.MAX_TOKENS -> stringResource(R.string.error_max_tokens)
                        MessageErrorType.EMPTY_RESPONSE -> stringResource(R.string.error_empty_response)
                        MessageErrorType.STREAM_INTERRUPTED -> stringResource(R.string.error_stream_interrupted)
                        else -> message.errorDetail ?: stringResource(R.string.error_stream_interrupted)
                    }
                    Text(text = errText, style = MaterialTheme.typography.bodyMedium, color = textColor)
                    if (!message.errorDetail.isNullOrBlank()) {
                        Text(
                            text = message.errorDetail,
                            style = MaterialTheme.typography.labelSmall,
                            color = textColor.copy(alpha = 0.8f)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (message.errorType == MessageErrorType.MISSING_API_KEY ||
                            message.errorType == MessageErrorType.INVALID_API_KEY
                        ) {
                            Button(onClick = onOpenSettings) {
                                Text(stringResource(R.string.open_settings))
                            }
                        }
                        OutlinedButton(onClick = onRetry) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(stringResource(R.string.retry))
                        }
                    }
                } else if (message.isPartial && !isStreamingThis) {
                    OutlinedButton(onClick = onRetry) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(stringResource(R.string.retry))
                    }
                }
            }
        }

        // Grounding source chips under assistant reply
        if (!isUser && message.groundingSources.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .padding(top = 4.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                message.groundingSources.forEach { src ->
                    AssistChip(
                        onClick = { runCatching { uriHandler.openUri(src.uri) } },
                        label = {
                            Text(
                                text = src.title,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.widthIn(max = 160.dp)
                            )
                        }
                    )
                }
            }
        }

        // Metadata & Action Row
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            modifier = Modifier.padding(top = 2.dp)
        ) {
            if (!isUser && !message.modelUsed.isNullOrBlank()) {
                Text(
                    text = message.modelUsed,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(end = 6.dp)
                )
            }
            if (message.content.isNotBlank()) {
                IconButton(
                    onClick = {
                        clipboard.setText(AnnotatedString(message.content))
                        Toast.makeText(context, context.getString(R.string.copied), Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = stringResource(R.string.copy), modifier = Modifier.size(16.dp))
                }
            }
            if (!isUser && message.content.isNotBlank() && !isStreamingThis) {
                IconButton(onClick = onReadAloud, modifier = Modifier.size(30.dp)) {
                    Icon(
                        imageVector = if (isSpeaking) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                        contentDescription = stringResource(if (isSpeaking) R.string.stop_reading else R.string.read_aloud),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            if (canRegenerate) {
                IconButton(onClick = onRegenerate, modifier = Modifier.size(30.dp)) {
                    Icon(Icons.Default.Refresh, contentDescription = stringResource(R.string.regenerate), modifier = Modifier.size(16.dp))
                }
            }
            if (canEdit) {
                IconButton(onClick = onEdit, modifier = Modifier.size(30.dp)) {
                    Icon(Icons.Default.Edit, contentDescription = stringResource(R.string.edit_and_resend), modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}
