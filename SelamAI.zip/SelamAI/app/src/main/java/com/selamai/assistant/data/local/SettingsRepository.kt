package com.selamai.assistant.data.local

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.selamai.assistant.domain.model.AppSettings
import com.selamai.assistant.domain.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SettingsRepository @Inject constructor(
    private val dataStore: DataStore<Preferences>
) {
    private object Keys {
        val DEFAULT_MODEL = stringPreferencesKey("default_model")
        val FALLBACK_CHAIN = stringPreferencesKey("fallback_chain")
        val LIVE_WEB_SEARCH = booleanPreferencesKey("live_web_search")
        val SYSTEM_PROMPT = stringPreferencesKey("system_prompt")
        val ASK_BEFORE_SAVING = booleanPreferencesKey("ask_before_saving")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val DYNAMIC_COLOR = booleanPreferencesKey("dynamic_color")
        val APP_LANGUAGE = stringPreferencesKey("app_language")
        val BIOMETRIC_LOCK = booleanPreferencesKey("biometric_lock")
    }

    val settingsFlow: Flow<AppSettings> = dataStore.data.map { prefs ->
        val rawFallback = prefs[Keys.FALLBACK_CHAIN]
        val fallbackList = if (rawFallback == null) {
            AppSettings.DEFAULT_FALLBACK_CHAIN
        } else {
            rawFallback.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        }
        AppSettings(
            defaultModel = prefs[Keys.DEFAULT_MODEL]?.takeIf { it.isNotBlank() }
                ?: AppSettings.DEFAULT_MODEL,
            fallbackModels = fallbackList,
            liveWebSearchEnabled = prefs[Keys.LIVE_WEB_SEARCH] ?: true,
            defaultSystemPrompt = prefs[Keys.SYSTEM_PROMPT]?.takeIf { it.isNotBlank() }
                ?: AppSettings.DEFAULT_SYSTEM_PROMPT,
            askBeforeSavingMemory = prefs[Keys.ASK_BEFORE_SAVING] ?: true,
            themeMode = prefs[Keys.THEME_MODE]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() }
                ?: ThemeMode.SYSTEM,
            dynamicColorEnabled = prefs[Keys.DYNAMIC_COLOR] ?: true,
            appLanguage = prefs[Keys.APP_LANGUAGE] ?: "en",
            biometricLockEnabled = prefs[Keys.BIOMETRIC_LOCK] ?: false
        )
    }

    suspend fun getSettingsOnce(): AppSettings = settingsFlow.first()

    suspend fun updateDefaultModel(model: String) {
        dataStore.edit { it[Keys.DEFAULT_MODEL] = model.trim() }
    }

    suspend fun updateFallbackChain(models: List<String>) {
        dataStore.edit { it[Keys.FALLBACK_CHAIN] = models.joinToString(",") }
    }

    suspend fun updateLiveWebSearch(enabled: Boolean) {
        dataStore.edit { it[Keys.LIVE_WEB_SEARCH] = enabled }
    }

    suspend fun updateSystemPrompt(prompt: String) {
        dataStore.edit { it[Keys.SYSTEM_PROMPT] = prompt.trim() }
    }

    suspend fun updateAskBeforeSaving(enabled: Boolean) {
        dataStore.edit { it[Keys.ASK_BEFORE_SAVING] = enabled }
    }

    suspend fun updateThemeMode(mode: ThemeMode) {
        dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun updateDynamicColor(enabled: Boolean) {
        dataStore.edit { it[Keys.DYNAMIC_COLOR] = enabled }
    }

    suspend fun updateAppLanguage(langTag: String) {
        dataStore.edit { it[Keys.APP_LANGUAGE] = langTag }
    }

    suspend fun updateBiometricLock(enabled: Boolean) {
        dataStore.edit { it[Keys.BIOMETRIC_LOCK] = enabled }
    }
}
