package com.selamai.assistant.data.local

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import com.selamai.assistant.domain.model.AttachmentType
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

data class SavedAttachment(
    val localPath: String,
    val mimeType: String,
    val displayName: String,
    val type: AttachmentType
)

class AttachmentTooLargeException(val maxBytes: Long) : Exception("Attachment exceeds max size")

@Singleton
class AttachmentManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        const val MAX_IMAGE_DIMENSION = 1280
        const val JPEG_QUALITY = 85
        const val MAX_PDF_BYTES = 15L * 1024L * 1024L // 15 MB
    }

    private val attachmentsDir: File
        get() = File(context.filesDir, "attachments").apply { mkdirs() }

    private val cameraCacheDir: File
        get() = File(context.cacheDir, "camera").apply { mkdirs() }

    fun createCameraCaptureUri(): Uri {
        val photoFile = File(cameraCacheDir, "capture_${System.currentTimeMillis()}.jpg")
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            photoFile
        )
    }

    /**
     * Reads an image URI, fixes EXIF rotation, scales down to max 1280px, and saves as local JPEG.
     */
    suspend fun processAndSaveImage(uri: Uri): SavedAttachment = withContext(Dispatchers.IO) {
        val orientation = context.contentResolver.openInputStream(uri)?.use { stream ->
            ExifInterface(stream).getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )
        } ?: ExifInterface.ORIENTATION_NORMAL

        val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, boundsOpts)
        }

        var inSampleSize = 1
        val maxSide = maxOf(boundsOpts.outWidth, boundsOpts.outHeight)
        while (maxSide / inSampleSize > MAX_IMAGE_DIMENSION * 2) {
            inSampleSize *= 2
        }

        val decodeOpts = BitmapFactory.Options().apply { this.inSampleSize = inSampleSize }
        val rawBitmap = context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, decodeOpts)
        } ?: throw IllegalArgumentException("Could not decode image")

        val rotated = applyExifOrientation(rawBitmap, orientation)
        if (rotated !== rawBitmap) rawBitmap.recycle()

        val scaled = scaleToMaxDimension(rotated, MAX_IMAGE_DIMENSION)
        if (scaled !== rotated) rotated.recycle()

        val outFile = File(attachmentsDir, "img_${UUID.randomUUID()}.jpg")
        FileOutputStream(outFile).use { fos ->
            scaled.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, fos)
        }
        scaled.recycle()

        SavedAttachment(
            localPath = outFile.absolutePath,
            mimeType = "image/jpeg",
            displayName = outFile.name,
            type = AttachmentType.IMAGE
        )
    }

    /**
     * Copies a PDF URI into local app storage after verifying it does not exceed 15 MB.
     */
    suspend fun processAndSavePdf(uri: Uri): SavedAttachment = withContext(Dispatchers.IO) {
        val displayName = queryDisplayName(uri) ?: "document.pdf"
        val size = queryFileSize(uri)
        if (size != null && size > MAX_PDF_BYTES) {
            throw AttachmentTooLargeException(MAX_PDF_BYTES)
        }

        val outFile = File(attachmentsDir, "pdf_${UUID.randomUUID()}.pdf")
        var totalRead = 0L
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(outFile).use { output ->
                val buffer = ByteArray(16 * 1024)
                while (true) {
                    val read = input.read(buffer)
                    if (read == -1) break
                    totalRead += read
                    if (totalRead > MAX_PDF_BYTES) {
                        outFile.delete()
                        throw AttachmentTooLargeException(MAX_PDF_BYTES)
                    }
                    output.write(buffer, 0, read)
                }
            }
        } ?: throw IllegalArgumentException("Could not read PDF file")

        SavedAttachment(
            localPath = outFile.absolutePath,
            mimeType = "application/pdf",
            displayName = displayName,
            type = AttachmentType.PDF
        )
    }

    suspend fun readAsBase64(localPath: String): String? = withContext(Dispatchers.IO) {
        val file = File(localPath)
        if (!file.exists()) return@withContext null
        Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)
    }

    fun deleteFiles(paths: List<String>) {
        paths.forEach { path ->
            runCatching { File(path).delete() }
        }
    }

    private fun applyExifOrientation(bitmap: Bitmap, orientation: Int): Bitmap {
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
            else -> return bitmap
        }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    private fun scaleToMaxDimension(bitmap: Bitmap, maxDim: Int): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= maxDim && h <= maxDim) return bitmap
        val ratio = minOf(maxDim.toFloat() / w, maxDim.toFloat() / h)
        val newW = (w * ratio).toInt().coerceAtLeast(1)
        val newH = (h * ratio).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, newW, newH, true)
    }

    private fun queryDisplayName(uri: Uri): String? {
        return context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
    }

    private fun queryFileSize(uri: Uri): Long? {
        return context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst() && !cursor.isNull(0)) cursor.getLong(0) else null
            }
    }
}
