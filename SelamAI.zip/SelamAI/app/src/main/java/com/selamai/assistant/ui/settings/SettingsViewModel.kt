package com.selamai.assistant.ui.settings

import android.net.Uri
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.selamai.assistant.data.local.EncryptedApiKeyStore
import com.selamai.assistant.data.local.ExportBackupManager
import com.selamai.assistant.data.local.SettingsRepository
import com.selamai.assistant.domain.model.AppSettings
import com.selamai.assistant.domain.model.ThemeMode
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val apiKeyStore: EncryptedApiKeyStore,
    private val exportBackupManager: ExportBackupManager
) : ViewModel() {

    val settings: StateFlow<AppSettings> = settingsRepository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())

    val hasApiKey: StateFlow<Boolean> = apiKeyStore.hasApiKeyFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    private val _statusMessages = MutableSharedFlow<String>()
    val statusMessages: SharedFlow<String> = _statusMessages.asSharedFlow()

    fun saveApiKey(rawKey: String, confirmationMessage: String) {
        viewModelScope.launch {
            apiKeyStore.saveApiKey(rawKey)
            _statusMessages.emit(confirmationMessage)
        }
    }

    fun updateDefaultModel(model: String) {
        viewModelScope.launch { settingsRepository.updateDefaultModel(model) }
    }

    fun updateFallbackChain(rawCsv: String) {
        val list = rawCsv.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        viewModelScope.launch { settingsRepository.updateFallbackChain(list) }
    }

    fun updateLiveWebSearch(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.updateLiveWebSearch(enabled) }
    }

    fun updateSystemPrompt(prompt: String) {
        viewModelScope.launch { settingsRepository.updateSystemPrompt(prompt) }
    }

    fun updateAskBeforeSaving(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.updateAskBeforeSaving(enabled) }
    }

    fun updateThemeMode(mode: ThemeMode) {
        viewModelScope.launch { settingsRepository.updateThemeMode(mode) }
    }

    fun updateDynamicColor(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.updateDynamicColor(enabled) }
    }

    fun updateAppLanguage(langTag: String) {
        viewModelScope.launch {
            settingsRepository.updateAppLanguage(langTag)
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(langTag))
        }
    }

    fun updateBiometricLock(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.updateBiometricLock(enabled) }
    }

    fun backupJson(uri: Uri, successMsg: String) {
        viewModelScope.launch {
            runCatching { exportBackupManager.writeFullBackupToUri(uri) }
                .onSuccess { _statusMessages.emit(successMsg) }
                .onFailure { _statusMessages.emit(it.message ?: "Backup failed") }
        }
    }

    fun restoreJson(uri: Uri, successMsg: String) {
        viewModelScope.launch {
            runCatching { exportBackupManager.restoreFullBackupFromUri(uri) }
                .onSuccess { _statusMessages.emit(successMsg) }
                .onFailure { _statusMessages.emit(it.message ?: "Restore failed") }
        }
    }
}
