package com.selamai.assistant

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class SelamAIApplication : Application()
