package com.selamai.assistant.ui.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.selamai.assistant.R
import com.selamai.assistant.domain.model.ThemeMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsState()
    val hasApiKey by viewModel.hasApiKey.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    var apiKeyInput by remember { mutableStateOf("") }
    var showApiKey by remember { mutableStateOf(false) }
    var defaultModelDraft by remember(settings.defaultModel) { mutableStateOf(settings.defaultModel) }
    var fallbackDraft by remember(settings.fallbackModels) {
        mutableStateOf(settings.fallbackModels.joinToString(", "))
    }
    var systemPromptDraft by remember(settings.defaultSystemPrompt) {
        mutableStateOf(settings.defaultSystemPrompt)
    }

    val backupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) viewModel.backupJson(uri, context.getString(R.string.backup_success))
    }

    val restoreLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) viewModel.restoreJson(uri, context.getString(R.string.restore_success))
    }

    LaunchedEffect(Unit) {
        viewModel.statusMessages.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.settings_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Section: Gemini API
            Text(
                text = stringResource(R.string.settings_api_section),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )

            OutlinedTextField(
                value = apiKeyInput,
                onValueChange = { apiKeyInput = it },
                label = { Text(stringResource(R.string.settings_api_key)) },
                placeholder = {
                    Text(
                        if (hasApiKey) "•••••••••••• (saved)"
                        else stringResource(R.string.settings_api_key_hint)
                    )
                },
                visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { showApiKey = !showApiKey }) {
                        Icon(
                            imageVector = if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = null
                        )
                    }
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    viewModel.saveApiKey(apiKeyInput, context.getString(R.string.settings_api_key_saved))
                    apiKeyInput = ""
                },
                enabled = apiKeyInput.isNotBlank()
            ) {
                Text(stringResource(R.string.save))
            }

            OutlinedTextField(
                value = defaultModelDraft,
                onValueChange = {
                    defaultModelDraft = it
                    viewModel.updateDefaultModel(it)
                },
                label = { Text(stringResource(R.string.settings_default_model)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = fallbackDraft,
                onValueChange = {
                    fallbackDraft = it
                    viewModel.updateFallbackChain(it)
                },
                label = { Text(stringResource(R.string.settings_fallback_chain)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = stringResource(R.string.settings_hydrogen_warning),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                    modifier = Modifier.padding(12.dp)
                )
            }

            SettingsSwitchRow(
                title = stringResource(R.string.settings_web_search),
                subtitle = stringResource(R.string.settings_web_search_desc),
                checked = settings.liveWebSearchEnabled,
                onCheckedChange = viewModel::updateLiveWebSearch
            )

            OutlinedTextField(
                value = systemPromptDraft,
                onValueChange = {
                    systemPromptDraft = it
                    viewModel.updateSystemPrompt(it)
                },
                label = { Text(stringResource(R.string.settings_system_prompt)) },
                minLines = 3,
                maxLines = 6,
                modifier = Modifier.fillMaxWidth()
            )

            HorizontalDivider()

            // Section: Memory
            Text(
                text = stringResource(R.string.settings_memory_section),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            SettingsSwitchRow(
                title = stringResource(R.string.settings_ask_before_saving),
                subtitle = null,
                checked = settings.askBeforeSavingMemory,
                onCheckedChange = viewModel::updateAskBeforeSaving
            )

            HorizontalDivider()

            // Section: Appearance & Language
            Text(
                text = stringResource(R.string.settings_appearance_section),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )

            Text(stringResource(R.string.settings_theme), style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = settings.themeMode == ThemeMode.SYSTEM,
                    onClick = { viewModel.updateThemeMode(ThemeMode.SYSTEM) },
                    label = { Text(stringResource(R.string.theme_system)) }
                )
                FilterChip(
                    selected = settings.themeMode == ThemeMode.LIGHT,
                    onClick = { viewModel.updateThemeMode(ThemeMode.LIGHT) },
                    label = { Text(stringResource(R.string.theme_light)) }
                )
                FilterChip(
                    selected = settings.themeMode == ThemeMode.DARK,
                    onClick = { viewModel.updateThemeMode(ThemeMode.DARK) },
                    label = { Text(stringResource(R.string.theme_dark)) }
                )
            }

            SettingsSwitchRow(
                title = stringResource(R.string.settings_dynamic_color),
                subtitle = null,
                checked = settings.dynamicColorEnabled,
                onCheckedChange = viewModel::updateDynamicColor
            )

            Text(stringResource(R.string.settings_language), style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = settings.appLanguage == "en",
                    onClick = { viewModel.updateAppLanguage("en") },
                    label = { Text(stringResource(R.string.lang_en)) }
                )
                FilterChip(
                    selected = settings.appLanguage == "am",
                    onClick = { viewModel.updateAppLanguage("am") },
                    label = { Text(stringResource(R.string.lang_am)) }
                )
            }

            HorizontalDivider()

            // Section: Security & Backup
            Text(
                text = stringResource(R.string.settings_security_section),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )

            SettingsSwitchRow(
                title = stringResource(R.string.settings_biometric_lock),
                subtitle = stringResource(R.string.settings_biometric_desc),
                checked = settings.biometricLockEnabled,
                onCheckedChange = viewModel::updateBiometricLock
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = { backupLauncher.launch("selamai_backup.json") },
                    modifier = Modifier.weight(1f)
                ) {
                    Text(stringResource(R.string.settings_backup_json))
                }
                OutlinedButton(
                    onClick = { restoreLauncher.launch(arrayOf("application/json")) },
                    modifier = Modifier.weight(1f)
                ) {
                    Text(stringResource(R.string.settings_restore_json))
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SettingsSwitchRow(
    title: String,
    subtitle: String?,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(text = title, style = MaterialTheme.typography.bodyLarge)
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
