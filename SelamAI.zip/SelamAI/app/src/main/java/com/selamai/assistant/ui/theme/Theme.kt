package com.selamai.assistant.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.selamai.assistant.domain.model.ThemeMode

private val SelamGreenPrimary = Color(0xFF0B6B3A)
private val SelamGreenLight = Color(0xFF078930)
private val SelamGold = Color(0xFFFCDD09)
private val SelamRed = Color(0xFFDA121D)

private val LightColors = lightColorScheme(
    primary = SelamGreenPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD2F4DF),
    onPrimaryContainer = Color(0xFF00210E),
    secondary = SelamGreenLight,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0F2E9),
    onSecondaryContainer = Color(0xFF0B2E1A),
    tertiary = Color(0xFF8A6D00),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFF0A6),
    onTertiaryContainer = Color(0xFF2B2100),
    error = SelamRed,
    background = Color(0xFFF7FAF7),
    surface = Color(0xFFF7FAF7),
    surfaceVariant = Color(0xFFE7EFE9)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF7ADBA2),
    onPrimary = Color(0xFF00391B),
    primaryContainer = SelamGreenPrimary,
    onPrimaryContainer = Color(0xFFD2F4DF),
    secondary = Color(0xFF9CD4B2),
    onSecondary = Color(0xFF07381F),
    secondaryContainer = Color(0xFF1A4D31),
    onSecondaryContainer = Color(0xFFC2F0D3),
    tertiary = SelamGold,
    onTertiary = Color(0xFF332800),
    error = Color(0xFFFFB4AB),
    background = Color(0xFF101511),
    surface = Color(0xFF101511),
    surfaceVariant = Color(0xFF1D2620)
)

@Composable
fun SelamAITheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val darkTheme = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColors
        else -> LightColors
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = SelamTypography,
        content = content
    )
}
