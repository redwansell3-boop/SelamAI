package com.selamai.assistant.domain.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

class EthiopianCalendarConverterTest {

    @Test
    fun convertsNormalYearNewYearSept11() {
        // 2024-09-11 Gregorian is Meskerem 1, 2017 E.C.
        val eth = EthiopianCalendarConverter.fromGregorian(LocalDate.of(2024, 9, 11))
        assertEquals(EthiopianDate(2017, 1, 1), eth)
        assertEquals("Meskerem", eth.monthNameEnglish)
        assertEquals("መስከረም", eth.monthNameAmharic)
    }

    @Test
    fun convertsLeapYearNewYearSept12() {
        // 2015 E.C. is an Ethiopian leap year (Pagume has 6 days, ending 2023-09-11),
        // so 2016 E.C. Meskerem 1 falls on 2023-09-12 Gregorian.
        assertTrue(EthiopianCalendarConverter.isEthiopianLeapYear(2015))
        assertFalse(EthiopianCalendarConverter.isEthiopianLeapYear(2016))

        val pagume6 = EthiopianCalendarConverter.fromGregorian(LocalDate.of(2023, 9, 11))
        assertEquals(EthiopianDate(2015, 13, 6), pagume6)

        val newYear2016 = EthiopianCalendarConverter.fromGregorian(LocalDate.of(2023, 9, 12))
        assertEquals(EthiopianDate(2016, 1, 1), newYear2016)
    }

    @Test
    fun convertsMidYearDateAccurately() {
        // 2026-11-22 Gregorian -> Hidar 13, 2019 E.C.
        val eth = EthiopianCalendarConverter.fromGregorian(LocalDate.of(2026, 11, 22))
        assertEquals(EthiopianDate(2019, 3, 13), eth)
        assertEquals("Hidar", eth.monthNameEnglish)
    }

    @Test
    fun clockBlockIncludesGregorianAndEthiopianDates() {
        val zdt = ZonedDateTime.of(2026, 11, 22, 18, 42, 0, 0, ZoneId.of("Africa/Addis_Ababa"))
        val block = EthiopianCalendarConverter.buildClockBlock(zdt)
        assertTrue(block.contains("2026-11-22"))
        assertTrue(block.contains("Hidar 13, 2019 E.C."))
        assertTrue(block.contains("Africa/Addis_Ababa"))
    }
}
