package com.selamai.assistant.domain.util

import com.selamai.assistant.domain.model.MemoryCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class StreamingMemoryParserTest {

    @Test
    fun buffersSplitTagAcrossChunksWithoutLeakingPartialTag() {
        val parser = StreamingMemoryParser()
        val chunks = listOf(
            "ሰላም! ",
            "እረዳዎታለሁ [",
            "[MEM",
            "ORY:Preference|Prefers dark ",
            "mode and Amharic replies]",
            "]"
        )

        val visible = StringBuilder()
        val memories = mutableListOf<ParsedMemoryCandidate>()

        for (chunk in chunks) {
            val res = parser.feed(chunk)
            visible.append(res.visibleTextDelta)
            memories.addAll(res.extractedMemories)
            assertFalse("Partial tag leaked: $visible", visible.toString().contains("[[MEM"))
        }
        val flushed = parser.flush()
        visible.append(flushed.visibleTextDelta)
        memories.addAll(flushed.extractedMemories)

        assertEquals("ሰላም! እረዳዎታለሁ ", visible.toString())
        assertEquals(1, memories.size)
        assertEquals(MemoryCategory.PREFERENCE, memories[0].category)
        assertEquals("Prefers dark mode and Amharic replies", memories[0].fact)
    }

    @Test
    fun flushesStrayBracketWhenNotAMemoryTag() {
        val parser = StreamingMemoryParser()
        val r1 = parser.feed("Array index [0]")
        val r2 = parser.flush()
        assertEquals("Array index [0]", r1.visibleTextDelta + r2.visibleTextDelta)
        assertEquals(0, r1.extractedMemories.size + r2.extractedMemories.size)
    }

    @Test
    fun discardsIncompleteMemoryTagOnFlush() {
        val parser = StreamingMemoryParser()
        val r1 = parser.feed("Answer text [[MEMORY:Goal|Learn Kotlin")
        val r2 = parser.flush()
        assertEquals("Answer text ", r1.visibleTextDelta + r2.visibleTextDelta)
        assertEquals(0, r1.extractedMemories.size + r2.extractedMemories.size)
    }
}
