package com.selamai.assistant.domain.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MarkdownParserTest {

    @Test
    fun parsesHeadingsBulletsNumberedAndBlockquotes() {
        val md = listOf(
            "# Main Title",
            "## Sub Title",
            "- First bullet",
            "- Second bullet",
            "1. Step one",
            "2. Step two",
            "> A wise quote"
        ).joinToString("\n")

        val blocks = MarkdownParser.parse(md)
        assertEquals(7, blocks.size)
        assertTrue(blocks[0] is MarkdownBlock.Heading && (blocks[0] as MarkdownBlock.Heading).level == 1)
        assertTrue(blocks[1] is MarkdownBlock.Heading && (blocks[1] as MarkdownBlock.Heading).level == 2)
        assertTrue(blocks[2] is MarkdownBlock.BulletItem)
        assertTrue(blocks[3] is MarkdownBlock.BulletItem)
        assertTrue(blocks[4] is MarkdownBlock.NumberedItem && (blocks[4] as MarkdownBlock.NumberedItem).number == 1)
        assertTrue(blocks[5] is MarkdownBlock.NumberedItem && (blocks[5] as MarkdownBlock.NumberedItem).number == 2)
        assertTrue(blocks[6] is MarkdownBlock.Blockquote)
    }

    @Test
    fun parsesInlineFormattingAndLinks() {
        val spans = MarkdownParser.parseInline(
            "Hello **bold**, *italic*, `code`, and [Google](https://google.com)."
        )
        assertTrue(spans.any { it == MarkdownSpan.Bold("bold") })
        assertTrue(spans.any { it == MarkdownSpan.Italic("italic") })
        assertTrue(spans.any { it == MarkdownSpan.InlineCode("code") })
        assertTrue(spans.any { it == MarkdownSpan.Link("Google", "https://google.com") })
    }

    @Test
    fun parsesFencedCodeBlocks() {
        val md = listOf("```kotlin", "val x = 42", "println(x)", "```").joinToString("\n")
        val blocks = MarkdownParser.parse(md)
        assertEquals(1, blocks.size)
        val codeBlock = blocks[0] as MarkdownBlock.CodeBlock
        assertEquals("kotlin", codeBlock.language)
        assertEquals("val x = 42\nprintln(x)", codeBlock.code)
    }
}
