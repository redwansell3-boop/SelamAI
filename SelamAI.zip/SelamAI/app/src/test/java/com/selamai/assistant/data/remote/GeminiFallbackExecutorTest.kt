package com.selamai.assistant.data.remote

import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GeminiFallbackExecutorTest {

    @Test
    fun retries503TwiceWithExponentialBackoffThenFallsBack() = runTest {
        val delays = mutableListOf<Long>()
        val calls = mutableListOf<String>()
        val executor = GeminiFallbackExecutor(
            delayFn = { delays.add(it) },
            jitterProvider = { 100L },
            baseBackoffMs = 1000L
        )

        val result = executor.execute(
            selectedModel = "gemini-3.5-flash-lite",
            fallbackModels = listOf("gemini-3.8-flash", "gemini-4-hydrogen")
        ) { model ->
            calls.add(model)
            if (model == "gemini-3.5-flash-lite") {
                ModelAttemptOutcome.HttpError(503)
            } else {
                ModelAttemptOutcome.Success(model, "ok")
            }
        }

        assertTrue(result is FallbackResult.Success)
        assertEquals("gemini-3.8-flash", (result as FallbackResult.Success).model)
        // 1 initial + 2 retries on flash-lite, then 1 call on 3.8-flash
        assertEquals(
            listOf(
                "gemini-3.5-flash-lite",
                "gemini-3.5-flash-lite",
                "gemini-3.5-flash-lite",
                "gemini-3.8-flash"
            ),
            calls
        )
        assertEquals(listOf(1100L, 2100L), delays)
    }

    @Test
    fun honors429RetryAfterOnceThenMovesToNextModel() = runTest {
        val delays = mutableListOf<Long>()
        val calls = mutableListOf<String>()
        val executor = GeminiFallbackExecutor(delayFn = { delays.add(it) })

        val result = executor.execute(
            selectedModel = "gemini-3.5-flash-lite",
            fallbackModels = listOf("gemini-3.8-flash")
        ) { model ->
            calls.add(model)
            if (model == "gemini-3.5-flash-lite") {
                ModelAttemptOutcome.HttpError(429, retryAfterHeader = "3")
            } else {
                ModelAttemptOutcome.Success(model, "ok")
            }
        }

        assertTrue(result is FallbackResult.Success)
        assertEquals("gemini-3.8-flash", (result as FallbackResult.Success).model)
        assertEquals(listOf(3000L), delays)
        assertEquals(
            listOf("gemini-3.5-flash-lite", "gemini-3.5-flash-lite", "gemini-3.8-flash"),
            calls
        )
    }

    @Test
    fun movesImmediatelyOn404AndNeverRepeatsModel() = runTest {
        val calls = mutableListOf<String>()
        val executor = GeminiFallbackExecutor(delayFn = {})

        val result = executor.execute(
            selectedModel = "gemini-3.8-flash",
            fallbackModels = listOf("gemini-3.8-flash", "gemini-4-hydrogen")
        ) { model ->
            calls.add(model)
            if (model == "gemini-3.8-flash") ModelAttemptOutcome.HttpError(404)
            else ModelAttemptOutcome.Success(model, "ok")
        }

        assertTrue(result is FallbackResult.Success)
        assertEquals(listOf("gemini-3.8-flash", "gemini-4-hydrogen"), calls)
    }

    @Test
    fun doesNotFallbackOn400_401_403() = runTest {
        for (code in listOf(400, 401, 403)) {
            val calls = mutableListOf<String>()
            val executor = GeminiFallbackExecutor(delayFn = {})
            val result = executor.execute(
                selectedModel = "gemini-3.5-flash-lite",
                fallbackModels = listOf("gemini-3.8-flash", "gemini-4-hydrogen")
            ) { model ->
                calls.add(model)
                ModelAttemptOutcome.HttpError(code, message = "API key invalid")
            }

            assertTrue("Expected InvalidApiKey for $code", result is FallbackResult.InvalidApiKey)
            assertEquals(1, calls.size)
        }
    }

    @Test
    fun returnsRateLimitExhaustedWhenAllModelsFailWith429() = runTest {
        val executor = GeminiFallbackExecutor(delayFn = {})
        val result = executor.execute(
            selectedModel = "gemini-3.5-flash-lite",
            fallbackModels = listOf("gemini-3.8-flash")
        ) {
            ModelAttemptOutcome.HttpError(429, retryAfterHeader = "1")
        }
        assertTrue(result is FallbackResult.RateLimitOrDemandExhausted)
    }
}
