package com.selamai.assistant.domain.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EthiopicLanguageDetectorTest {

    @Test
    fun detectsAmharicTextAsAmEt() {
        assertTrue(EthiopicLanguageDetector.containsEthiopic("ሰላም እንደምን አለህ?"))
        assertEquals("am-ET", EthiopicLanguageDetector.detectTtsLocaleTag("ሰላም እንደምን አለህ?"))
    }

    @Test
    fun detectsEnglishTextAsEnUs() {
        assertFalse(EthiopicLanguageDetector.containsEthiopic("Hello, how are you today?"))
        assertEquals("en-US", EthiopicLanguageDetector.detectTtsLocaleTag("Hello, how are you today?"))
    }

    @Test
    fun detectsMixedEthiopicAndLatinAsAmEt() {
        assertEquals("am-ET", EthiopicLanguageDetector.detectTtsLocaleTag("SelamAI ሰላም ነው"))
    }

    @Test
    fun detectsEmptyOrNumericAsEnUs() {
        assertEquals("en-US", EthiopicLanguageDetector.detectTtsLocaleTag(""))
        assertEquals("en-US", EthiopicLanguageDetector.detectTtsLocaleTag("2026-11-22 12:30"))
    }
}
